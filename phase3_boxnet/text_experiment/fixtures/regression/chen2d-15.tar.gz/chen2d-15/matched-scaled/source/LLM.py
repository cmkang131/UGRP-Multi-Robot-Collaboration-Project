"""Chen's model entry point, exact message traces, and the read-only RealLLM bridge."""
import os
import sys
from contextvars import ContextVar
from decimal import Decimal
from functools import partial, wraps
from pathlib import Path
from tempfile import TemporaryDirectory
from threading import Lock
from time import monotonic

import fake_model
from limits import CALL_CEILING, CLIENT_LIMIT, MODEL_SERVICE, OUTPUT_LIMIT, TOKEN_LIMIT, StopEpisode
from storage import read_json, write_json

BRAIN = Path(os.environ.get("BOXNET_BRAIN_DIR", Path(__file__).resolve().parents[1] / "planner_client"))
MODEL = "z-ai/glm-5.3-flash"
QWEN = "qwen/qwen3-235b-a22b-2507"
SMALL_QWEN = "qwen/qwen3.5-9b"
REASONING_SETTINGS = ("default", "off")
MAX_OUTPUT_TOKENS = 8192
MAX_ATTEMPTS = 3
_session = ContextVar("chen_model_session")
_finish_capture = ContextVar("chen_provider_finish", default=None)
_decoder_lock = Lock()
_LENGTH_REASONS = {"length", "max_tokens", "max_output_tokens"}


def capture_provider_finish(api):
    """Older clients discard the choice's finish fields after decoding the provider body.

    Observe just those fields from the same strict decode, before content validation.
    A context variable keeps simultaneous attempts separate. Native retries, redaction,
    validation and both spending ledgers remain on the ordinary client path.
    """
    with _decoder_lock:
        decode = getattr(api, "_strict_json", None)
        if decode is None or getattr(decode, "_chen_finish_observer", False):
            return

        @wraps(decode)
        def observe(*args, **kwargs):
            value = decode(*args, **kwargs)
            target = _finish_capture.get()
            if target is not None and isinstance(value, dict):
                choices = value.get("choices")
                if isinstance(choices, list) and len(choices) == 1 and isinstance(choices[0], dict):
                    for key in ("finish_reason", "native_finish_reason"):
                        reason = choices[0].get(key)
                        if isinstance(reason, str):
                            target[key] = reason
            return value

        observe._chen_finish_observer = True
        api._strict_json = observe


def finish_fields(entry, observed):
    reasons = {k: entry.get(k) or observed.get(k) for k in ("finish_reason", "native_finish_reason")}
    raw = entry.get("cut_off")
    known = [v.lower() for v in reasons.values() if isinstance(v, str) and v]
    cut = True if any(r in _LENGTH_REASONS for r in known) else (
        raw if isinstance(raw, bool) else False if known else None)
    return dict(**reasons, cut_off=cut)


def validate_reasoning(model, setting):
    if setting not in REASONING_SETTINGS:
        raise ValueError(f"Unknown reasoning setting: {setting}")
    if setting == "off" and model == MODEL:
        raise ValueError(f"--reasoning off is unavailable for {model}: this model requires reasoning")
    if setting == "off" and model == QWEN:
        raise ValueError(f"--reasoning off is unavailable for {model}: its profile has no reasoning parameter")
    return setting


def load_real_api():
    # Even an invocation without -B must never create __pycache__ in the source tree.
    sys.dont_write_bytecode = True
    sys.path.insert(0, str(BRAIN))
    try:
        import llm
        if Path(llm.__file__).resolve() != (BRAIN / "llm.py").resolve():
            raise ImportError("Unexpected RealLLM import path")
        return llm
    finally:
        sys.path.remove(str(BRAIN))


def wire_prompt(messages):
    # RealLLM accepts one string. Keep every turn's content, order and whitespace.
    return "\n\n".join(f'[{m["role"]}]\n{m["content"]}' for m in messages)


def usage_from_record(record, kind, invocation):
    reported = None if record.get("cost_decision") else record.get("cost_usd")
    return dict(kind=kind, invocation=invocation, temperature=record["temperature"],
                api_calls=int(not record.get("cache_hit", False)),
                prompt_tokens=record.get("input_tokens"), completion_tokens=record.get("output_tokens"),
                reasoning_tokens=record.get("reasoning_tokens"), cost_usd=reported,
                guard_cost_usd=record.get("cost_usd"), cost_decision=record.get("cost_decision"),
                attempt_id=record.get("attempt_id"), actual_model=record.get("actual_model"), provider=record.get("provider"),
                logical_call_id=record.get("logical_call_id"), raw_output=record.get("raw_output"),
                cache_hit=record.get("cache_hit", False))


def call_usage(attempts):
    usage = dict(attempt_count=len(attempts), attempt_kinds=[a["kind"] for a in attempts],
                 api_calls=sum(a["api_calls"] for a in attempts),
                 cache_hit=any(a["cache_hit"] for a in attempts))
    for field in ("prompt_tokens", "completion_tokens", "reasoning_tokens"):
        values = [a[field] for a in attempts]
        known = sum(v for v in values if v is not None)
        usage["known_" + field] = known
        usage[field] = None if None in values else known
    for field in ("cost_usd", "guard_cost_usd"):
        values = [a[field] for a in attempts]
        known = sum((Decimal(str(v)) for v in values if v is not None), Decimal(0))
        usage[field] = None if None in values else float(known)
        if field == "cost_usd":
            usage["known_reported_cost_usd"] = float(known)
    return usage


class CallSession:
    def __init__(self, directory, budget, model, script, ceiling, max_output_tokens=MAX_OUTPUT_TOKENS,
                 temperature=0.0, retry_temperature=None, *, reasoning_setting="default",
                 max_attempts=MAX_ATTEMPTS, trace_finish=False):
        # An unversioned standalone replay uses the original scripted trace format.
        self.reasoning_setting = reasoning_setting
        setting = validate_reasoning(model, "default" if reasoning_setting is None else reasoning_setting)
        self.directory = directory / "calls"
        self.directory.mkdir(exist_ok=True)
        self.budget, self.model, self.script = budget, model, script
        self.records = []
        for number, path in enumerate(sorted(self.directory.glob("[0-9]*.json")), 1):
            record = read_json(path)
            if record["number"] != number or record["status"] == "pending":
                raise ValueError(f"Unresolved call trace at {path}. Inspect it before resuming.")
            if (record["model"], record.get("reasoning_setting", "default")) != (model, setting):
                raise ValueError(f"Saved model or reasoning setting changed: {path}")
            self.records.append(record)
        self.cursor = self.api_calls = self.step = self.round = 0
        self.planning_round = None
        self.speaker = self.role = None
        self.told = False
        self.ceiling = ceiling
        self.max_attempts = max_attempts
        self.trace_finish = trace_finish
        self.max_output_tokens = max_output_tokens
        self.temperature = temperature
        self.retry_temperature = temperature if retry_temperature is None else retry_temperature
        self.client = None
        if model != "fake":
            self.api = load_real_api()
            if trace_finish:
                capture_provider_finish(self.api)
            self.ceiling = min(ceiling, self.api.HARD_EPISODE_CALLS)

            class EpisodeClient(self.api.RealLLM):
                # Native call() owns retry decisions and sleeps. Meter each physical attempt at its boundary.
                def _call_once(client, prompt, **options):
                    return client.account_attempt(super()._call_once, prompt, **options)

            # RealLLM selects reasoning and provider price ceilings from the requested model's profile.
            self.client = EpisodeClient(
                min(self.max_attempts, self.ceiling), directory / "client-calls.jsonl", model=model,
                reasoning={"enabled": False} if setting == "off" else None,
                campaign_log_path=directory / "campaign-calls.jsonl",
                budget_usd=self.api.HARD_CAMPAIGN_USD, temperature=temperature,
                max_output_tokens=max_output_tokens, retry_total_s=0 if max_attempts == 1 else self.api.RETRY_TOTAL_S,
                cache_dir=directory / "cache")

    def __enter__(self):
        self.binding = _session.set(self)
        return self

    def __exit__(self, *_):
        _session.reset(self.binding)

    def call(self, messages):
        if self.api_calls >= self.ceiling:
            raise StopEpisode(CALL_CEILING)
        if self.cursor < len(self.records):
            record = self.records[self.cursor]
            if (record["messages"], record["step"], record["round"], record["speaker"], record["role"], record["told"]) != (
                    messages, self.step, self.round, self.speaker, self.role, self.told) or (
                    record.get("planning_round") != self.planning_round):
                raise ValueError("Saved call differs from the resumed protocol")
            if record["status"] == "interrupted":
                record = self.new_call(messages, record)
        else:
            record = self.new_call(messages)
            self.records.append(record)
        self.cursor += 1
        self.api_calls += record["api_calls"]
        if record.get("failure"):
            raise StopEpisode(record["failure"], record["detail"], interrupted=record["status"] == "interrupted")
        if self.api_calls >= self.ceiling and self.role != "relay" and not self.trace_finish:
            raise StopEpisode(CALL_CEILING)
        prompt, completion = record["prompt_tokens"], record["completion_tokens"]
        tokens = prompt + completion if prompt is not None and completion is not None else None
        return record["response"], tokens

    def mark_rescue(self):
        # A reply can pass through both the extraction site and the checker.
        record = self.records[self.cursor - 1]
        if not record["lenient_rescue"]:
            record["lenient_rescue"] = True
            write_json(self.directory / f"{record['number']:05d}.json", record)

    def record_own_reply(self, parsed):
        if parsed is None:
            return
        record = self.records[self.cursor - 1]
        fields = dict(own_reply_form=parsed.form, own_reply_padded=parsed.padded,
                      own_reply_cut=parsed.cut, own_reply_invalid_position=parsed.invalid_position,
                      lenient_rescue=parsed.rescued)
        if any(record.get(key) != value for key, value in fields.items()):
            record.update(fields)
            write_json(self.directory / f"{record['number']:05d}.json", record)

    def new_call(self, messages, record=None):
        number = self.cursor + 1
        path = self.directory / f"{number:05d}.json"
        key = str(path.relative_to(self.budget.out))
        if record is None:
            record = dict(number=number, step=self.step, round=self.round, speaker=self.speaker,
                          role=self.role, told=self.told, lenient_rescue=False, attempts=[],
                          invocation=self.budget.path.stem, model=self.model, messages=messages,
                          response=None, usage_source="api" if self.client is not None else "scripted")
            if self.reasoning_setting is not None:
                record["reasoning_setting"] = self.reasoning_setting
            if self.planning_round is not None:
                record["planning_round"] = self.planning_round
            if self.role == "own":
                record.update(own_reply_form=None, own_reply_padded=False, own_reply_cut=False,
                              own_reply_invalid_position=None)
        record.update(status="pending", failure=None, detail="")
        started = monotonic()
        write_json(path, record)
        try:
            if self.client is None:
                cost = fake_model.COST
                self.budget.reserve(key, cost)
                record["response"] = fake_model.reply(messages, self.script)
                record["attempts"].append(dict(kind="ok", invocation=self.budget.path.stem, api_calls=1,
                                               temperature=self.temperature,
                                               prompt_tokens=11, completion_tokens=7,
                                               reasoning_tokens=0 if self.reasoning_setting == "off" else 2,
                                               cost_usd=float(cost), guard_cost_usd=float(cost), cache_hit=False))
                if self.reasoning_setting is not None:
                    record["attempts"][-1]["provider"] = None
                if self.trace_finish:
                    record["attempts"][-1].update(finish_reason="stop", native_finish_reason=None, cut_off=False,
                                                  raw_output=record["response"])
                self.budget.settle(key, 1, cost, cost)
            else:
                self.real_call(wire_prompt(messages), record, key)
            record["status"] = "ok"
        except StopEpisode as stop:
            record.update(failure=stop.label, detail=stop.detail, status="interrupted" if stop.interrupted else "error")
            if not record["attempts"] and (stop.interrupted or stop.label == CLIENT_LIMIT):
                record.update(call_usage([]), status="refused")
                write_json(path, record)
                path.replace(self.directory / f"refused-{self.budget.path.stem}-{number}.json")
                raise
        except BaseException:
            # Keep uncertain attempts identifiable even if their settlement already reached disk.
            with self.budget.transaction() as state:
                state.update(stop_label=CLIENT_LIMIT, stop_detail=f"Unresolved attempt: {key}")
            raise
        record.update(call_usage(record["attempts"]))
        record["elapsed_seconds"] = record.get("elapsed_seconds", 0) + (monotonic() - started)
        write_json(path, record)
        return record

    def account_attempt(self, attempts, key, reserve, send, wire, **options):
        if self.trace_finish and len(attempts) >= self.max_attempts:
            raise self.api.CallLimitError("Per-instance call cap reached")
        key = f"{key}#{len(attempts) + 1}"
        self.budget.reserve(key, reserve)
        before = len(self.client.records)
        kind = "ok"
        observed = {}
        binding = _finish_capture.set(observed) if self.trace_finish else None
        try:
            with TemporaryDirectory(dir=self.directory, prefix=".response-cache-") as cache:
                self.client.cache_dir = Path(cache)
                self.client.temperature = (self.retry_temperature if attempts and attempts[-1]["kind"] == "truncated"
                                           else self.temperature)
                return send(wire, **options)
        except Exception as exc:
            if len(self.client.records) == before:
                if isinstance(exc, self.api.InfraError):
                    raise StopEpisode(MODEL_SERVICE, exc.kind, interrupted=True) from None
                if (isinstance(exc, (OSError, RuntimeError, ValueError)) and not isinstance(exc, self.api.CallLimitError)
                        and str(exc) != "Conservative input token cap exceeded"):
                    raise StopEpisode(MODEL_SERVICE, type(exc).__name__, interrupted=True) from None
            kind = getattr(exc, "retry_kind", type(exc).__name__)
            raise
        finally:
            if binding is not None:
                _finish_capture.reset(binding)
            entries = self.client.records[before:]
            if entries:
                entry, = entries
                attempt = usage_from_record(entry, kind, self.budget.path.stem)
                if self.trace_finish:
                    attempt.update(finish_fields(entry, observed))
                if attempt["cache_hit"] or entry["status"] == "started":
                    raise RuntimeError("Unexpected cache hit or unresolved client attempt")
                attempts.append(attempt)
                charge = attempt["guard_cost_usd"]
                self.budget.settle(key, 1, Decimal(str(attempt["cost_usd"] or 0)),
                                   None if charge is None else Decimal(str(charge)))
            else:
                # The episode ledger or the client preflight refused before transport.
                self.budget.settle(key, 0, Decimal(0), Decimal(0))

    def real_call(self, wire, result, key):
        attempts = result["attempts"]
        remaining = min(self.max_attempts, self.ceiling - self.api_calls) - len(attempts)
        # max_calls is cumulative for a client instance. Prefix attempts already settled on resume
        # occupy slots in this author call as well as in its episode.
        self.client.max_calls = self.client.call_count + remaining
        price = self.client.max_price
        reserve = (Decimal(len(wire.encode("utf-8")) + 1024) * Decimal(str(price["prompt"])) +
                   self.max_output_tokens * Decimal(str(price["completion"]))) / 1_000_000
        self.client.account_attempt = partial(self.account_attempt, attempts, key, reserve)
        try:
            reply = self.client.call(wire, response_format=None)
            result.update(response=reply["raw_output"], attempt_id=reply["attempt_id"],
                          actual_model=reply.get("actual_model"))
            return
        except self.api.CallLimitError as exc:
            if str(exc) != "Per-instance call cap reached":
                raise StopEpisode(CLIENT_LIMIT, str(exc), interrupted=str(exc) != "Campaign dollar budget exhausted") from None
            if len(attempts) < self.max_attempts:
                raise StopEpisode(CALL_CEILING, str(exc)) from None
            detail = attempts[-1]["kind"]
        except self.api.InfraError as exc:
            detail = exc.kind
        except (self.api.TransportError, ValueError) as exc:
            if str(exc) == "Conservative input token cap exceeded":
                raise StopEpisode(TOKEN_LIMIT, "RealLLM conservative input bound") from None
            raise StopEpisode(MODEL_SERVICE, type(exc).__name__, interrupted=not attempts) from None
        if self.trace_finish:
            length_stop = bool(attempts) and all(a["cut_off"] is True for a in attempts)
        else:
            length_stop = detail == "truncated" and attempts and all(a["kind"] == detail for a in attempts)
        label = OUTPUT_LIMIT if length_stop else MODEL_SERVICE
        raise StopEpisode(label, detail)


def GPT_response(messages, model_name):
    session = _session.get()
    if session.model != model_name:
        raise ValueError("Model does not match the episode")
    return session.call(messages)
