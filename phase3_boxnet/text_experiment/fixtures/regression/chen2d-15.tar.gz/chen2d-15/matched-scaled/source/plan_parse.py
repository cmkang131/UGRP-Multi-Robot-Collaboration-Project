"""Plan selection at the authors' extraction and syntactic-check sites."""
import ast
import json
import re
from dataclasses import dataclass
from decimal import Decimal

DECODER = json.JSONDecoder()
BRACED = re.compile(r"{.*}", re.DOTALL)
OPEN_BRACE = re.compile(r"{")
COORD = r"(\d+(?:\.\d+)?)"
COORD_PAIR = rf"\[\s*{COORD}\s*,\s*{COORD}\s*\]"
PLAN_AGENT = re.compile("Agent" + COORD_PAIR)
STEP_KEY = re.compile(r"(?:step\s+)?(0*[1-9][0-9]*)", re.IGNORECASE)
OWN_MOVE = re.compile(r"move\((box_\w+),\s(?:(target_\w+|dropoff(?:_\w+)?)|square" + COORD_PAIR + r")\)")
SPACED_MOVE = re.compile(r"move\s*\(\s*(box_\w+)\s*,\s*(?:(target_\w+|dropoff(?:_\w+)?)|square\s*"
                         + COORD_PAIR + r")\s*\)")
OWN_FORMS = ("list", "nested", "self_dict", "string", "fenced")
JSON_NULL = re.compile(r"\bnull\b")
UNUSABLE = object()


def unique_keys(pairs):
    obj = dict(pairs)
    if len(obj) != len(pairs):
        raise ValueError("Repeated key in OWN reply")
    return obj


OWN_DECODER = json.JSONDecoder(object_pairs_hook=unique_keys)


def python_own_value(node):
    # Read literal data only. An unknown expression is an unusable entry, never an action.
    if isinstance(node, ast.List):
        return [python_own_value(item) for item in node.elts]
    if isinstance(node, ast.Dict):
        if not all(isinstance(k, ast.Constant) and isinstance(k.value, str) for k in node.keys):
            raise ValueError("Expected string keys")
        return unique_keys([(k.value, python_own_value(v)) for k, v in zip(node.keys, node.values)])
    if isinstance(node, ast.Constant):
        return node.value
    if isinstance(node, ast.Name) and node.id == "null":
        return None
    return UNUSABLE


def decode_own_value(text):
    try:
        return OWN_DECODER.decode(text), False
    except json.JSONDecodeError:
        if not text.startswith(("[", "{")):
            raise
    try:
        node = ast.parse(text, mode="eval").body
    except SyntaxError as exc:
        raise ValueError("Invalid OWN literal") from exc
    if not isinstance(node, (ast.List, ast.Dict)):
        raise ValueError("Expected an OWN list or object")
    return python_own_value(node), True


def own_prefix(text):
    """Split a damaged outer list at its own commas, preserving the first broken slot."""
    if not text.startswith("["):
        return None
    fields = []
    start, depth, quote, escaped = 1, 0, "", False
    for i in range(start, len(text)):
        char = text[i]
        if quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
        elif char in "\"'":
            quote = char
        elif char in "[{":
            depth += 1
        elif char in "]}":
            if not depth:
                if char != "]" or text[i + 1:].strip():
                    return None
                if text[start:i].strip():
                    fields.append(text[start:i])
                break
            depth -= 1
        elif char == "," and not depth:
            fields.append(text[start:i])
            start = i + 1
    else:
        fields.append("")  # The final entry never closed.
    entries = []
    for field in fields:
        # The enclosing list supports both Python-quoted and JSON entries.
        try:
            item, _ = decode_own_value("[" + field + "]")
        except (ValueError, RecursionError):
            break
        if len(item) != 1 or item[0] is UNUSABLE:
            break
        entries.append(item[0])
    if 0 < len(entries) < len(fields):
        return entries + [UNUSABLE] * (len(fields) - len(entries))
    return None


def embedded_values(text, *, own=False, prior_shapes=False):
    """Scan complete top-level values without selecting members of a rejected container."""
    start, depth, quote, escaped = 0, 0, "", False
    scalar_end = 0
    for i, char in enumerate(text):
        if i < scalar_end:
            continue
        if not depth:
            if char in "[{":
                start, depth = i, 1
            elif own and (char == '"' or (char == "n" and JSON_NULL.match(text, i))):
                try:
                    value, scalar_end = OWN_DECODER.raw_decode(text, i)
                except (ValueError, RecursionError):
                    continue
                yield value
        elif quote:
            if escaped:
                escaped = False
            elif char == "\\":
                escaped = True
            elif char == quote:
                quote = ""
        elif char == '"' or (own and not prior_shapes and char == "'"):
            quote = char
        elif char in "[{":
            depth += 1
        elif char in "]}":
            depth -= 1
            if not depth:
                fragment = text[start:i + 1]
                try:
                    if own and not prior_shapes:
                        yield decode_own_value(fragment)[0]
                    else:
                        yield (OWN_DECODER if own else DECODER).decode(fragment)
                except (ValueError, RecursionError):
                    if own and not prior_shapes:
                        prefix = own_prefix(fragment)
                        if prefix is not None:
                            yield prefix


def own_entry(value):
    return value is None or (isinstance(value, str) and OWN_MOVE.fullmatch(value) is not None)


def speaker_coordinates(name):
    match = PLAN_AGENT.fullmatch(name) if isinstance(name, str) else None
    return tuple(map(Decimal, match.groups())) if match else None


def as_sequence(value, horizon, own, lenient, *, agent_positions=None, format_errors=None, prior_shapes=False):
    if not own and lenient and isinstance(value, dict):
        steps = [] if prior_shapes else [STEP_KEY.fullmatch(k.strip()) for k in value]
        if steps and all(steps):
            numbered = {Decimal(m[1]): plan for m, plan in zip(steps, value.values())}
            if len(numbered) != len(value):
                if format_errors is not None:
                    format_errors.append("Each step number must appear only once.")
                return None
            value = [numbered[n] for n in sorted(numbered)]
        elif len(value) == 1 and isinstance(next(iter(value.values())), list):
            value = next(iter(value.values()))
        elif prior_shapes and any(isinstance(v, list) for v in value.values()):
            return None
        else:
            value = [value]
    if not isinstance(value, list) or len(value) > horizon:
        return None
    if own:
        if len(value) != horizon or not all(own_entry(v) for v in value):
            return None
    else:
        for plan in value:
            if not isinstance(plan, dict):
                return None
            if prior_shapes:
                continue
            for key in plan:
                position = speaker_coordinates(key)
                if position is None or (agent_positions is not None and position not in agent_positions):
                    if format_errors is not None:
                        format_errors.append(f"{json.dumps(key)} is not an agent name on this board. "
                                             "Use an Agent[row, col] key from the current state in each joint plan.")
                    return None
    return value


@dataclass(frozen=True)
class OwnReply:
    entries: list
    form: str
    padded: bool = False
    cut: bool = False
    invalid_position: int | None = None
    normalized: bool = False

    @property
    def rescued(self):
        return self.form != "list" or self.padded or self.cut or self.normalized or self.invalid_position is not None


def normalize_own_entry(value):
    if isinstance(value, dict) and value.keys() == {"action"}:
        value = value["action"]
    if own_entry(value):
        return value
    if not isinstance(value, str):
        return UNUSABLE
    text = value.strip()
    if text.lower() in ("", "null", "none", "wait"):
        return None
    match = SPACED_MOVE.fullmatch(text)
    if match is None:
        return UNUSABLE
    box, site, row, col = match.groups()
    if row is not None:
        site = f"square[{row}, {col}]"
    return f"move({box}, {site})"


def own_value(value, horizon, speaker, *, embedded=False, normalized=False, prior_shapes=False):
    form = "fenced" if embedded else "list"
    if isinstance(value, dict):
        if len(value) != 1:
            return None
        (name, value), = value.items()
        coords = speaker_coordinates(name)
        if coords is None or coords != speaker_coordinates(speaker or "") or not isinstance(value, list):
            return None
        form = "self_dict"
    elif not isinstance(value, list):
        if prior_shapes:
            return OwnReply([value], "string") if horizon == 1 and own_entry(value) else None
        entry = normalize_own_entry(value)
        if entry is None:
            return OwnReply([None] * horizon, "string", padded=horizon > 1)
        return OwnReply([entry], "string") if horizon == 1 and entry is not UNUSABLE else None

    if value and isinstance(value[0], list):
        if len(value) == 1:
            value = value[0]
        else:
            value = [entry[0] if isinstance(entry, list) and len(entry) == 1 else UNUSABLE for entry in value]
        if form != "self_dict":
            form = "nested"
    if prior_shapes and not all(own_entry(entry) for entry in value):
        return None
    size = len(value)
    entries = []
    invalid_position = None
    for position, raw in enumerate(value, 1):
        entry = normalize_own_entry(raw)
        if entry is UNUSABLE:
            if not 1 < position <= horizon:
                return None
            invalid_position = position
            break
        normalized |= entry != raw
        if position <= horizon:
            entries.append(entry)
    entries.extend([None] * (horizon - len(entries)))
    return OwnReply(entries, form, padded=size < horizon, cut=size > horizon,
                    invalid_position=invalid_position, normalized=normalized)


def parse_own_reply(reply, horizon, speaker, mode, *, prior_shapes=False):
    if mode == "strict":
        try:
            value = json.loads(reply)
        except (ValueError, RecursionError):
            return None
        entries = as_sequence(value, horizon, own=True, lenient=False)
        return OwnReply(entries, "list") if entries is not None else None

    try:
        value, normalized = (OWN_DECODER.decode(reply), False) if prior_shapes else decode_own_value(reply.strip())
    except (ValueError, RecursionError):
        text = reply.rsplit("EXECUTE", 1)[-1].strip()
        if horizon == 1 and (OWN_MOVE if prior_shapes else SPACED_MOVE).fullmatch(text):
            return own_value(text, horizon, speaker)
        prefix = None if prior_shapes else own_prefix(text)
        if prefix is not None:
            return own_value(prefix, horizon, speaker, embedded=reply.strip() != text)
        for candidate in embedded_values(text, own=True, prior_shapes=prior_shapes):
            selected = own_value(candidate, horizon, speaker, embedded=True, prior_shapes=prior_shapes)
            if selected is not None:
                return selected
        return None
    return own_value(value, horizon, speaker, normalized=normalized, prior_shapes=prior_shapes)


def first_object(reply):
    start = max(0, reply.rfind("EXECUTE"))
    for match in OPEN_BRACE.finditer(reply, start):
        try:
            obj, _ = DECODER.raw_decode(reply, match.start())
        except (ValueError, RecursionError):
            continue
        if isinstance(obj, dict):
            # Keep insertion order: the authors' executor applies actions in that order.
            return json.dumps(obj)
    return None


class PlanParser:
    def __init__(self, mode="lenient", mark_rescue=None, *, record_own=None):
        if mode not in ("lenient", "strict"):
            raise ValueError(f"Unknown parse mode {mode}")
        self.mode = mode
        self.mark_rescue = mark_rescue
        self.record_own = record_own

    def _select(self, reply, strict_candidate):
        selected = first_object(reply)
        if self.mark_rescue is not None and strict_candidate is not None:
            try:
                original = json.loads(strict_candidate)
                different = not isinstance(original, dict) or json.dumps(original) != selected
            except (ValueError, RecursionError):
                different = True
            if different:
                self.mark_rescue()
        return selected

    def extract(self, reply, *, revision=False, selecting=True):
        match = BRACED.search(reply)
        candidate = match.group() if match else None
        if self.mode == "strict":
            return candidate
        if not selecting:
            # HMAS-1 also uses the brace search as a dialogue-loop sentinel.
            return candidate
        # The upstream HMAS-2 revision gives the checker the whole reply if it matched.
        return self._select(reply, reply if revision and match else candidate)

    def for_check(self, reply):
        if self.mode == "strict":
            return reply
        return self._select(reply, reply)

    def sequence(self, reply, horizon, *, own=False, dialogue=False, speaker=None, legacy_own=False,
                 agent_positions=None, format_errors=None, prior_shapes=False):
        """Select a joint sequence or the submitting robot's own entries."""
        if own and not legacy_own:
            parsed = parse_own_reply(reply, horizon, speaker, self.mode, prior_shapes=prior_shapes)
            if self.record_own is not None:
                self.record_own(parsed)
            elif parsed and parsed.rescued and self.mark_rescue is not None:
                self.mark_rescue()
            return parsed.entries if parsed else None
        if dialogue:
            # EXECUTE is the DMAS protocol envelope. Strict parsing still requires a bare list inside it.
            reply = reply.rsplit("EXECUTE", 1)[-1].strip()
        try:
            value = json.loads(reply)
        except (ValueError, RecursionError):
            if self.mode == "strict":
                return None
            for candidate in embedded_values(reply.rsplit("EXECUTE", 1)[-1]):
                selected = as_sequence(candidate, horizon, own, True, agent_positions=agent_positions,
                                       format_errors=format_errors, prior_shapes=prior_shapes)
                if selected is not None:
                    if self.mark_rescue is not None:
                        self.mark_rescue()
                    return selected
            return None
        selected = as_sequence(value, horizon, own, self.mode == "lenient", agent_positions=agent_positions,
                               format_errors=format_errors, prior_shapes=prior_shapes)
        if selected is not None and not isinstance(value, list) and self.mark_rescue is not None:
            self.mark_rescue()
        return selected
