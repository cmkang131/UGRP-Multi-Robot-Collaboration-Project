"""Planning-round counters shared by episode publication and the comparison tools."""
from collections import Counter, defaultdict
import json
from statistics import median

from limits import CALL_CEILING, CALL_LIMIT, CLIENT_LIMIT, COST_LIMIT, MODEL_SERVICE, OUTPUT_LIMIT, TOKEN_LIMIT
from plan_parse import OWN_FORMS


ITERATION_LIMIT = "failure over query time limit"
ENV_STEP_LIMIT = "failure over environment step limit"
MATCHED_ENV_CAP = "environment step ceiling"
MATCHED_ROUND_CAP = "planning round ceiling"
MATCHED_CALL_CAP = "episode call ceiling"
MATCHED_CEILINGS = (MATCHED_ENV_CAP, MATCHED_ROUND_CAP, MATCHED_CALL_CAP)
CUTOFF_COUNTS = {
    "no cut-off": "rounds_no_cutoff",
    "first attempt cut off and recovered": "rounds_cutoff_recovered",
    "all attempts cut off": "rounds_all_attempts_cutoff",
    "unknown": "rounds_cutoff_unknown",
}
ROUND_COUNTS = ("plans_proposed", "effective_steps", "empty_steps_skipped", "discarded_steps", "untried_steps_after_invalid")
DMAS_RETENTIONS = ("dmas_unparsable_overwrites_prevented", "dmas_empty_overwrites_prevented")
CUT_ROLES = ("leader", "final_dmas_speaker", "individual_robot", "repair_call", "dialogue_turn", "other")
COMPARISON_GROUP = ("model", "reasoning_setting", "framework", "horizon", "max_output_tokens", "size",
                    "condition", "speech", "tell", "history_method", "history_window", "cmas_history",
                    "state_position", "max_env_steps")


def round_cutoff(calls):
    """A round can have many writers. An exhausted required call stops the whole round."""
    recovered, unknown = False, not calls
    for call in calls:
        flags = [a.get("cut_off") for a in call["attempts"] if a["api_calls"]]
        if flags and all(f is True for f in flags) and call.get("failure") == OUTPUT_LIMIT:
            return "all attempts cut off"
        if not flags or None in flags:
            unknown = True
        elif any(flags):
            if flags[0] and flags[-1] is False and call["status"] == "ok":
                recovered = True
            else:
                unknown = True
    if unknown:
        return "unknown"
    return "first attempt cut off and recovered" if recovered else "no cut-off"


def blocked_cause(batch, label):
    if label in (*MATCHED_CEILINGS, CALL_CEILING, CALL_LIMIT, COST_LIMIT, CLIENT_LIMIT, TOKEN_LIMIT):
        return "ceiling"
    if label == OUTPUT_LIMIT:
        return "output limit"
    if label == MODEL_SERVICE:
        return "model service"
    reason = batch.get("stop_reason")
    checks = [c for c in batch.get("checks", ()) if c.get("own_dropped")]
    if reason == "invalid" or any(c["status"] == "invalid" for c in checks):
        return "not-doable actions"
    if reason == "parse failure" or checks:
        return "unusable replies after repairs"
    if reason == "all empty":
        return "no actions proposed"
    return "unknown"


def matched_measurements(row, calls):
    by_round = defaultdict(list)
    for call in calls:
        by_round[call.get("planning_round")].append(call)
    log = row["round_log"]
    counts = dict.fromkeys(CUTOFF_COUNTS.values(), 0)
    first, cause, stage = None, None, None
    label = row["success_failure"]
    for batch in log:
        n = batch["planning_round"]
        batch["cutoff_class"] = round_cutoff(by_round[n])
        counts[CUTOFF_COUNTS[batch["cutoff_class"]]] += 1
        terminal = label if batch is log[-1] else None
        if first is None and not batch["effective_steps"]:
            # A round may produce no usable action and still be followed by a replan.
            # If the round's own result was known before reaching the round cap, retain it.
            observed = None if terminal == MATCHED_ROUND_CAP and batch["checks"] else terminal
            first, cause, stage = n, blocked_cause(batch, observed), "before a joint action"
        elif first is None and terminal in MATCHED_CEILINGS:
            first, cause, stage = n, "ceiling", "after executed actions"
    if not log and label in MATCHED_CEILINGS:
        first, cause, stage = 0, "ceiling", "before the first planning round"
    row.update(**counts, first_blocked_round=first, first_blocked_cause=cause, first_blocked_stage=stage,
               repair_calls=sum(b["repair_calls"] for b in log),
               robots_dropped=sum(len(b["dropped_robots"]) for b in log))


def matched_cell_metrics(rows):
    causes = Counter(row.get("first_blocked_cause") or "none" for row in rows)
    strict = sum(r["finished"] and r["strict_success"] for r in rows)
    metrics = {k: sum(r[k] for r in rows) for k in CUTOFF_COUNTS.values()}
    metrics.update(strict_completions=strict, first_blocked_causes=dict(sorted(causes.items())))
    for ending in MATCHED_CEILINGS:
        metrics["ended_on_" + ending.replace(" ", "_")] = sum(r["success_failure"] == ending for r in rows)
    for field, name in (("api_calls", "calls"), ("prompt_tokens", "prompt_tokens"),
                        ("completion_tokens", "generated_tokens")):
        values = [row[field] for row in rows]
        total = None if None in values else sum(values)
        metrics["total_" + name] = total
        metrics[name + "_per_strict_completion"] = ("no completion" if not strict else
                                                    None if total is None else total / strict)
    return metrics


def repair_feedback(call):
    messages = call.get("messages", ())
    if len(messages) < 3 or messages[-1]["role"] != "user" or messages[-2]["role"] != "assistant":
        return ""
    feedback = messages[-1]["content"]
    if feedback.startswith(("The reply could not be read in the requested JSON format.",
                            "First-step actions outside the current doable lists: ")):
        return feedback
    if feedback.startswith("Joint plan format error. "):
        return feedback
    if call.get("role") == "own" and feedback.startswith(("Your reply could not be read as a JSON list of ",
                                                          "Your first entry ")):
        return feedback
    if feedback.startswith("Your assigned task for ") and "not in the doable action list" in feedback:
        return feedback
    if feedback.startswith("Your assigned plan is ") and "not in the correct json format" in feedback.lower():
        return feedback
    return ""


def cutoff_records(row, calls):
    """Count physical cut attempts, including those recovered by the same logical call."""
    final = {b["planning_round"]: b.get("final_submission_call", b.get("final_call"))
             for b in row.get("round_log", ())}
    if row["framework"] == "DMAS" and row.get("horizon", 1) == 1:
        for call in calls:
            if call["role"] == "dialogue" and not repair_feedback(call) and "EXECUTE" in (call.get("response") or ""):
                final[call["step"]] = call["number"]
    cuts = []
    for call in calls:
        count = sum(a["api_calls"] for a in call["attempts"]
                    if (a.get("cut_off") is True if row.get("protocol") == "matched" else a["kind"] == "truncated"))
        if not count:
            continue
        number, role = call["number"], call["role"]
        batch = call.get("planning_round", call["step"])
        terminal = call is calls[-1] and row["success_failure"] == OUTPUT_LIMIT
        if repair_feedback(call):
            who = "repair_call"
        elif role == "central":
            who = "leader"
        elif role == "own":
            who = "individual_robot"
        elif role == "dialogue":
            who = ("final_dmas_speaker" if row["framework"] == "DMAS" and (number == final.get(batch) or terminal)
                   else "dialogue_turn")
        else:
            who = "other"
        cuts.append(dict(call=number, planning_round=batch, speaker=call.get("speaker"),
                         role=who, attempts=count, terminal=terminal))
    return cuts


def fill_planning_counts(row):
    """Recover comparable counters for archived traces, including empty steps once charged."""
    by_round = defaultdict(list)
    for it in row.get("iterations", ()):
        by_round[it.get("planning_round", it["step"])].append(it)
    if "round_log" not in row:
        row["round_log"] = [dict(planning_round=n, plans_proposed=sum(it["executed"] for it in steps))
                            for n, steps in by_round.items()]
    for batch in row["round_log"]:
        if "effective_steps" not in batch:
            batch["effective_steps"] = sum(bool(it.get("applied_actions")) for it in by_round[batch["planning_round"]]
                                           if it["executed"])
        batch.setdefault("empty_steps_skipped", 0)
        invalid = batch.get("invalid_position")
        batch.setdefault("discarded_steps", max(0, batch["plans_proposed"] - invalid + 1) if invalid else 0)
        batch["untried_steps_after_invalid"] = max(0, batch["discarded_steps"] - 1)
    row.update({k: sum(b[k] for b in row["round_log"]) for k in ROUND_COUNTS})


def ending_counts(row):
    done = bool(row["finished"] and row["strict_success"])
    label = row["success_failure"] if row["finished"] and not done else None
    return dict(completed=int(done), ended_by_output_limit=int(label == OUTPUT_LIMIT),
                ended_by_syntactic_error=int(label == "Syntactic Error"),
                ended_by_iteration_limit=int(label == ITERATION_LIMIT),
                ended_by_env_step_limit=int(label == ENV_STEP_LIMIT))


def recorded_rule_counts(rows):
    return tuple(f for f in (*DMAS_RETENTIONS, "own_prefixes_kept", "own_unreachable_skipped")
                 if any(f in row for row in rows))


def comparison_metrics(rows, *, include_own=False, rule_counts=None):
    endings, cuts, terminal_cuts = Counter(), Counter(), Counter()
    effective = []
    for row in rows:
        endings.update(ending_counts(row))
        for cut in row.get("cut_calls", ()):
            cuts[cut["role"]] += cut["attempts"]
            if cut["terminal"]:
                terminal_cuts[cut["role"]] += 1
        effective.extend(b["effective_steps"] for b in row.get("round_log", ()))
    calls = sum(r["api_calls"] for r in rows)
    counts = {k: sum(r.get(k, 0) for r in rows) for k in ROUND_COUNTS}
    if rule_counts is None:
        rule_counts = recorded_rule_counts(rows)
    rules = {k: sum(r[k] for r in rows) if rows and all(k in r for r in rows) else None for k in rule_counts}
    own = {}
    if include_own or any(r.get("framework") == "OWN" for r in rows):
        # A group of archived or non-OWN episodes has no recorded OWN counters.
        measured = bool(rows) and all("own_reply_form_counts" in r for r in rows)
        for form in OWN_FORMS:
            own["own_reply_form_" + form] = sum(r["own_reply_form_counts"].get(form, 0) for r in rows) if measured else None
        own["own_robots_dropped"] = sum(r["own_robots_dropped"] for r in rows) if measured else None
    return dict(episodes=len(rows), completed=endings["completed"], ended_by_output_limit=endings["ended_by_output_limit"],
                ended_by_syntactic_error=endings["ended_by_syntactic_error"],
                ended_by_iteration_limit=endings["ended_by_iteration_limit"],
                ended_by_env_step_limit=endings["ended_by_env_step_limit"], **counts,
                planning_rounds=len(effective), model_calls=calls,
                median_effective_steps_per_planning_round=median(effective) if effective else None,
                effective_steps_per_model_call=sum(effective) / calls if calls else None,
                **{"cut_" + role: cuts[role] for role in CUT_ROLES},
                **{"output_limit_" + role: terminal_cuts[role] for role in CUT_ROLES}, **own, **rules)


def print_planning_table(rows, stream):
    groups = defaultdict(list)
    include_own = any(row["framework"] == "OWN" for row in rows)
    rule_counts = recorded_rule_counts(rows)
    fields = COMPARISON_GROUP
    if any(row.get("map_set", "legacy") != "legacy" or row.get("protocol") == "matched" for row in rows):
        fields += ("map_set", "protocol", "max_planning_rounds", "episode_call_ceiling")
    for row in rows:
        key = tuple(row.get(k, "legacy" if k in ("map_set", "protocol") else None) for k in fields)
        groups[key].append(row)
    print("Planning outcomes and physical calls", file=stream)
    print(" | ".join((*fields, *comparison_metrics([], include_own=include_own, rule_counts=rule_counts))), file=stream)
    for key in sorted(groups, key=lambda k: tuple(map(str, k))):
        stats = comparison_metrics(groups[key], include_own=include_own, rule_counts=rule_counts)
        print(" | ".join([*("-" if v is None else str(v) for v in key),
                          *("NA" if v is None else str(v) for v in stats.values())]), file=stream)


def print_matched_table(rows, stream):
    groups = defaultdict(list)
    fields = (*COMPARISON_GROUP, "map_set", "max_planning_rounds", "episode_call_ceiling")
    for row in rows:
        if row.get("protocol") == "matched":
            groups[tuple(row.get(k) for k in fields)].append(row)
    if not groups:
        return
    print("Matched protocol, all physical attempts per strict completion", file=stream)
    print(" | ".join((*fields, *matched_cell_metrics([]))), file=stream)
    for key in sorted(groups, key=lambda k: tuple(map(str, k))):
        values = matched_cell_metrics(groups[key])
        values["first_blocked_causes"] = json.dumps(values["first_blocked_causes"], sort_keys=True)
        print(" | ".join("NA" if v is None else str(v) for v in (*key, *values.values())), file=stream)
