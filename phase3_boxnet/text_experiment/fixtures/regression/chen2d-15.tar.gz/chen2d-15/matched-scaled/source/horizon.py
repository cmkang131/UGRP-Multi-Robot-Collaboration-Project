"""Joint and individual list planning on the authors' BoxNet1 environment."""
import json
import re
from dataclasses import dataclass, field
from pathlib import Path

from env1_create import (MAX_REPAIRS, action_from_response, plan_feedback, square_actions,
                         state_update_func, state_update_func_local_agent, surround_index_func)
from limits import OUTPUT_LIMIT, StopEpisode
import matched_protocol as matched
from map_events import agent_at, cell_key, coordinates, distance
from plan_parse import OWN_MOVE, PLAN_AGENT
from planning_metrics import (DMAS_RETENTIONS, ENV_STEP_LIMIT, ITERATION_LIMIT, MATCHED_CALL_CAP,
                              MATCHED_ENV_CAP, MATCHED_ROUND_CAP)
from prompt_env1 import (OWN_DIALOGUE, input_prompt_1_func_total, input_prompt_local_agent_DMAS_dialogue_func,
                         message_construct_func)

OWN_MAX_REPAIRS = 2


def validate_horizon(horizon, framework=None):
    if type(horizon) is not int or horizon < 1:
        raise ValueError("--horizon must be a positive integer")
    if horizon > 1 and framework not in (None, "CMAS", "DMAS", "OWN"):
        raise ValueError(f"--horizon > 1 requires CMAS, DMAS or OWN, got {framework}")
    return horizon


def available_actions(runtime):
    rows, cols = runtime.spec.rows, runtime.spec.cols
    actions = {}
    for i in range(rows):
        for j in range(cols):
            square = (i + .5, j + .5)
            actions[agent_at(square)] = square_actions(runtime.state[cell_key(square)],
                surround_index_func(rows, cols, i, j), runtime.condition == "e2")
    return actions


def check_joint(state, plan, available, returned_only):
    """Keep the single-proposal check and close its silent malformed/off-board cases."""
    encoded = json.dumps(plan)
    try:
        feedback = plan_feedback(state, encoded, encoded, returned_only)
    except re.error:
        feedback = ""
    bad, assigned = {}, set()
    for name, move in plan.items():
        coords = PLAN_AGENT.fullmatch(name)
        square = tuple(map(float, coords.groups())) if coords else None
        agent = agent_at(square) if square else name
        action = OWN_MOVE.fullmatch(move) if isinstance(move, str) else None
        if action:
            box, site, row, col = action.groups()
            if row is not None:
                site = f"square{[float(row), float(col)]}"
            if agent not in assigned and f"move({box}, {site})" in available.get(agent, ()):
                assigned.add(agent)
                continue
        bad[name] = move
        sentence = f"Your assigned task for {cell_key(square) if square else name} is not in the doable action list; "
        if sentence not in feedback:
            feedback += sentence
    return feedback, bad


@dataclass
class Turn:
    speaker: str
    users: list
    replies: list = field(default_factory=list)
    entries: list | None = None
    call: int | None = None
    feedback: str = ""
    initial_peers: str | None = None


class PlanningRound:
    def __init__(self, runtime, folder, number, first_step, history, method):
        self.rt, self.folder, self.history, self.method = runtime, folder, history, method
        self.spec = runtime.spec
        self.matched = self.spec.protocol == "matched"
        self.own = self.spec.framework == "OWN"
        self.dmas = self.spec.framework == "DMAS"
        self.dialogue = ""
        self.returned_only = runtime.condition == "e2"
        self.available = available_actions(runtime)
        self.agent_positions = {coordinates(key) for key in runtime.state}
        self.turns = {}
        self.log = dict(planning_round=number, first_step=first_step, plans_proposed=0, plans_executed=0,
                        effective_steps=0, empty_steps_skipped=0, discarded_steps=0,
                        proposed_plans=[], stop_reason=None, invalid_position=None, checks=[])
        if self.own:
            self.log.update(own_robots_dropped=0, own_unreachable_skipped=0)
            boxes = [coordinates(k) for k, items in runtime.state.items() if any(item.startswith("box_") for item in items)]
            self.unreachable = {agent_at(p) for p in self.agent_positions
                                if all(distance(p, box) > self.spec.horizon for box in boxes)}
        if self.dmas:
            self.log.update(dict.fromkeys(DMAS_RETENTIONS, 0))
        if self.matched:
            self.log.update(repair_calls=0, repair_calls_by_writer={}, repair_attempts=0, dropped_robots=[])
        runtime.round_log.append(self.log)

    def peer_lists(self):
        return json.dumps({s: t.entries for s, t in self.turns.items()})

    def local_turn(self, i, j, dialogue):
        rt, spec = self.rt, self.spec
        speaker = agent_at((i + .5, j + .5))
        local, others = state_update_func_local_agent(spec.rows, spec.cols, i, j, rt.state, self.returned_only)
        notice = rt.address(speaker, "own" if self.own else "dialogue")
        prompt = input_prompt_local_agent_DMAS_dialogue_func(local, others, dialogue, *self.history, self.method,
            notice, history_window=spec.history_window, horizon=spec.horizon,
            own_horizon=spec.horizon if self.own else None, state_position=spec.state_position)
        return Turn(speaker, [rt.with_messages(prompt)], initial_peers=dialogue if self.own else None)

    def matched_turn(self, robot=None):
        rt, spec = self.rt, self.spec
        speaker = rt.leader if robot is None else agent_at((robot[0] + .5, robot[1] + .5))
        role = "central" if robot is None else "own"
        notice = rt.address(speaker, role)
        earlier = {s: turn.entries for s, turn in self.turns.items()}
        prompt = matched.build_prompt(spec.rows, spec.cols, rt.state, self.history[0], self.history[1],
            horizon=spec.horizon, history_method=self.method, history_window=spec.history_window,
            state_position=spec.state_position, robot=robot, earlier=earlier, returned_only=self.returned_only,
            announcement=notice, dropoff_rule=spec.dropoff_rule)
        prompt = rt.relay.insert(prompt, speaker, role)
        return Turn(speaker, [prompt], initial_peers=json.dumps(earlier) if self.own else None)

    def initial_turns(self):
        rt, spec = self.rt, self.spec
        if self.matched:
            if self.own:
                for index in range(len(rt.robots)):
                    yield self.matched_turn(divmod(index, spec.cols))
            else:
                yield self.matched_turn()
            return
        if not self.own:
            state = state_update_func(spec.rows, spec.cols, rt.state, self.returned_only)
            prompt = input_prompt_1_func_total(state, *self.history, self.method, "CMAS", rt.address_central(),
                cmas_history=spec.cmas_history == "on", horizon=spec.horizon, history_window=spec.history_window)
            yield Turn(rt.leader, [rt.with_messages(prompt)])
            return
        for index, speaker in enumerate(rt.robots):
            if spec.horizon == 1 and not self.available[speaker]:
                continue
            i, j = divmod(index, spec.cols)
            yield self.local_turn(i, j, self.peer_lists())

    def ask(self, turn, *, repair=False):
        rt = self.rt
        if repair:
            role = {"OWN": "own", "DMAS": "dialogue", "CMAS": "central"}[self.spec.framework]
            rt.address(turn.speaker, role)
            if self.matched:
                instruction = matched.REPAIR_INSTRUCTION
            elif self.own:
                horizon = self.spec.horizon
                example = self.available[turn.speaker][:1]
                example += [None] * (horizon - len(example))
                instruction = (f"Output only a list like {json.dumps(example)} with {self.own_list_length()}, "
                               "each one action string for yourself or null.")
                instruction += "\n" + OWN_DIALOGUE + turn.initial_peers
            else:
                instruction = "Please replan the whole list for all the agents again with the same output format."
            turn.users.append(turn.feedback.rstrip() + " " + instruction)
        else:
            (self.folder / "prompt" / f"user_prompt_{self.log['first_step']}").write_text(turn.users[0])
        messages = message_construct_func(turn.users, turn.replies, "_w_all_dialogue_history")
        previous = rt.session.cursor
        try:
            reply, _ = rt.session.call(messages)
        finally:
            if self.matched and repair and rt.session.cursor > previous:
                self.log["repair_calls"] += 1
                self.log["repair_attempts"] += rt.session.records[previous]["api_calls"]
                writers = self.log["repair_calls_by_writer"]
                writers[turn.speaker] = writers.get(turn.speaker, 0) + 1
        turn.replies.append(reply)
        return reply

    def own_list_length(self):
        h = self.spec.horizon
        return f"{h} {'entry' if h == 1 else 'entries'}"

    def check_first(self, turn, *, repair=False):
        rt, reply = self.rt, turn.replies[-1]
        turn.call = rt.session.cursor
        errors = []
        parsed = rt.parser.sequence(reply, self.spec.horizon, own=self.own, dialogue=self.dmas, speaker=turn.speaker,
                                    agent_positions=self.agent_positions, format_errors=errors)
        turn.entries = parsed
        if turn.entries is None or (not turn.entries and not complete(rt)):
            turn.entries = None
            if self.own:
                turn.feedback = f"Your reply could not be read as a JSON list of {self.own_list_length()}."
            elif errors:
                turn.feedback = "Joint plan format error. " + errors[0]
            else:
                turn.feedback = plan_feedback(rt.state, None, reply, self.returned_only)
            status, bad = "parse failure", {}
        else:
            first = turn.entries[0] if turn.entries else {}
            plan = first
            if self.own:
                plan = {turn.speaker: first} if first is not None else {}
            turn.feedback, bad = check_joint(rt.state, plan, self.available, self.returned_only)
            if self.own and turn.feedback:
                turn.feedback = (f"Your first entry {json.dumps(first)} is not in your doable action list "
                                 f"{json.dumps(self.available[turn.speaker])}. Choose from that list or use null.")
                turn.entries = None
            status = "invalid" if turn.feedback else "valid"
        if self.matched:
            if status == "parse failure":
                turn.feedback = matched.UNREADABLE
            elif status == "invalid":
                turn.feedback = matched.INVALID_ACTIONS + json.dumps(bad) + "."
        check = dict(call=turn.call, speaker=turn.speaker, repair=repair, status=status, rejected_actions=bad)
        if errors and turn.entries is None and not self.own:
            check["feedback"] = turn.feedback
        self.log["checks"].append(check)
        if not self.own and (not self.dmas or repair):
            self.log.update(final_call=turn.call, final_speaker=turn.speaker)
        return parsed

    def consider_dmas_submission(self, turn):
        parsed = self.check_first(turn)
        previous = next(iter(self.turns.values()), None)
        if previous is not None and previous.entries is not None:
            if parsed is not None and not any(parsed) and any(previous.entries):
                self.log["dmas_empty_overwrites_prevented"] += 1
                return
            if turn.entries is None:
                self.log["dmas_unparsable_overwrites_prevented"] += 1
                return
        # Until a parsable plan exists, the last refusal identifies the writer to repair.
        self.turns = {turn.speaker: turn}
        self.log.update(final_speaker=turn.speaker, final_call=turn.call, final_submission_call=turn.call)
        self.record_proposal()

    def discuss(self):
        # EXECUTE still breaks only the authors' inner (column) loop.
        for sweep in range(1, 5):
            self.rt.set_round(sweep)
            for i in range(self.spec.rows):
                for j in range(self.spec.cols):
                    turn = self.local_turn(i, j, self.dialogue)
                    reply = self.ask(turn)
                    self.dialogue += f"[{turn.speaker}: {reply}]\n\n"
                    submitted = "EXECUTE" in reply
                    if submitted:
                        self.consider_dmas_submission(turn)
                    self.rt.finish_dialogue_turn()
                    if submitted:
                        break
            if self.turns:
                return
        self.log["stop_reason"] = "no agreement"

    def merged_plans(self):
        if not self.own:
            return next(iter(self.turns.values())).entries or []
        return [{s: t.entries[i] for s, t in self.turns.items() if t.entries is not None and t.entries[i] is not None}
                for i in range(self.spec.horizon)]

    def record_proposal(self):
        plans = self.merged_plans()
        self.log.update(proposed_plans=plans, plans_proposed=len(plans))
        return plans

    def repair_own(self):
        limit = matched.REPAIRS_PER_WRITER if self.matched else OWN_MAX_REPAIRS
        for attempt in range(1, limit + 1):
            for turn in self.turns.values():
                if not turn.feedback:
                    continue
                self.ask(turn, repair=True)
                self.check_first(turn, repair=True)
                self.rt.finish_dialogue_turn()
                if attempt == limit and turn.feedback:
                    self.log["own_robots_dropped"] += 1
                    self.log["checks"][-1]["own_dropped"] = True
                    if self.matched:
                        self.log["dropped_robots"].append(turn.speaker)
                    turn.feedback = ""
                self.record_proposal()

    def propose(self):
        if self.dmas:
            self.discuss()
            if not self.turns:
                return []
        else:
            for turn in self.initial_turns():
                self.turns[turn.speaker] = turn
                self.ask(turn)
                self.check_first(turn)
                if self.own:
                    if (not self.matched and turn.feedback and not self.available[turn.speaker]
                            and turn.speaker in self.unreachable):
                        turn.feedback = ""
                        self.log["own_unreachable_skipped"] += 1
                        self.log["checks"][-1]["repair_skipped"] = "no box within horizon"
                    self.rt.finish_dialogue_turn()
        self.record_proposal()
        if self.own:
            self.repair_own()
            return self.log["proposed_plans"]

        turn, = self.turns.values()
        limit = matched.REPAIRS_PER_WRITER if self.matched else MAX_REPAIRS
        for attempt in range(1, limit + 1):
            if not turn.feedback:
                break
            self.ask(turn, repair=True)
            if self.matched or attempt < limit:
                self.check_first(turn, repair=True)
            self.record_proposal()
        if turn.feedback:
            unparsable = turn.entries is None
            self.log.update(stop_reason="parse failure" if unparsable else "invalid",
                            invalid_position=None if unparsable else 1, discarded_steps=self.log["plans_proposed"])
            raise StopEpisode("Syntactic Error")
        return self.log["proposed_plans"]

    def execute(self, plans):
        rt = self.rt
        responses, states, dialogues = self.history
        rt.finish_planning()
        transcript = self.peer_lists() if self.own else self.dialogue
        for position, plan in enumerate(plans, 1):
            if complete(rt):
                break
            if not plan and (self.matched or self.spec.horizon > 1):
                self.log["empty_steps_skipped"] += 1
                continue
            available = self.available if position == 1 else available_actions(rt)
            feedback, bad = check_joint(rt.state, plan, available, self.returned_only)
            if feedback:
                self.log.update(stop_reason="invalid", invalid_position=position, feedback=feedback,
                                discarded_steps=len(plans) - position + 1,
                                rejected_actions=bad, rejected_calls={
                                    agent: self.turns[agent].call if self.own else self.log["final_call"] for agent in bad})
                return
            applied = []
            feedback, state = action_from_response(rt.state, plan, applied, returned_only=self.returned_only)
            if feedback or len(applied) != len(plan):
                raise ValueError("BoxNet1 executor disagrees with its checked doable actions")
            first_executed = self.log["plans_executed"] == 0
            step = len(states)
            if not first_executed:
                rt.begin_iteration(step, continuation=True)
            row = rt.iterations[-1]
            if self.own:
                row["action_calls"] = {agent: self.turns[agent].call for agent in plan}
            plan_call = None if self.own else self.log["final_call"]
            state = rt.executed(state, plan, applied, feedback, plan_call)
            responses.append(json.dumps(plan))
            states.append(state)
            dialogues.append(transcript if first_executed else "")
            (self.folder / "response" / f"response{step}.json").write_text(responses[-1])
            (self.folder / "pg_state" / f"pg_state{step + 1}.json").write_text(json.dumps(state))
            if self.own or self.dmas:
                (self.folder / "dialogue_history" / f"dialogue_history{step - 1}.txt").write_text(dialogues[-1])
            self.log["plans_executed"] += 1
            self.log["effective_steps"] += int(bool(applied))
            rt.relay_after_step(step)
            if step == self.spec.max_env_steps and not complete(rt):
                self.log["stop_reason"] = "environment step limit"
                return
        if complete(rt):
            self.log["stop_reason"] = "complete"
        elif plans and not plans[-1] and (self.matched or self.spec.horizon > 1):
            self.log["stop_reason"] = "empty tail" if self.log["effective_steps"] else "all empty"
        elif self.log["stop_reason"] is None:
            self.log["stop_reason"] = "all executed"


def complete(runtime):
    if runtime.condition == "static" and runtime.spec.dropoff == "event":
        return not any(runtime.state.values())
    return runtime.boxes_left == 0


def run_rounds(directory, runtime, limit, method):
    folder = Path(directory)
    for name in ("prompt", "response", "pg_state", "dialogue_history"):
        (folder / name).mkdir(exist_ok=True)
    history = ([], [runtime.state], [])
    (folder / "pg_state" / "pg_state1.json").write_text(json.dumps(runtime.state))
    is_matched = runtime.spec.protocol == "matched"
    if runtime.spec.max_env_steps == 0:
        return "success" if complete(runtime) else (MATCHED_ENV_CAP if is_matched else ENV_STEP_LIMIT)
    if is_matched and (not limit or complete(runtime)):
        return "success" if complete(runtime) else MATCHED_ROUND_CAP
    if is_matched and runtime.session.ceiling == 0:
        return MATCHED_CALL_CAP
    if runtime.spec.history_window == 0:
        method = "_wo_any_dialogue_history"
    runtime.relay_after_step(0)
    for number in range(1, limit + 1):
        step = len(history[1])
        runtime.session.planning_round = number
        runtime.begin_iteration(step)
        runtime.set_round(1)
        batch = PlanningRound(runtime, folder, number, step, history, method)
        try:
            batch.execute(batch.propose())
        except StopEpisode as stop:
            if batch.log["stop_reason"] is None:
                batch.log["stop_reason"] = "output limit" if stop.label == OUTPUT_LIMIT else stop.label
            if batch.log["plans_proposed"] and any(t.feedback and t.entries is not None for t in batch.turns.values()):
                batch.log.update(invalid_position=1, discarded_steps=batch.log["plans_proposed"])
            raise
        if complete(runtime):
            break
        if batch.log["stop_reason"] == "environment step limit":
            return MATCHED_ENV_CAP if is_matched else ENV_STEP_LIMIT
        if is_matched and runtime.session.api_calls >= runtime.session.ceiling:
            return MATCHED_CALL_CAP
    if is_matched:
        return "success" if complete(runtime) else MATCHED_ROUND_CAP
    return "success" if number < limit else ITERATION_LIMIT
