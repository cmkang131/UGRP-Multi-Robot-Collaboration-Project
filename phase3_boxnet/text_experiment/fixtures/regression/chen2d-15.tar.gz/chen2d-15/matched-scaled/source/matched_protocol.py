"""Shared CMAS/OWN writing instructions and execution-history layout for the matched protocol."""
import json

from env1_create import state_update_func
from map_events import agent_at
from prompt_env1 import AfterHistoryPrompt, OWN_DIALOGUE, state_action_history

REPAIRS_PER_WRITER = 2
DEFAULT_ENV_STEPS = 30
DEFAULT_PLANNING_ROUNDS = 30
STATE_HEADING = "Current board and doable actions:"
HISTORY_HEADING = "Earlier executed state and action pairs:"
GOAL = "Match all boxes to their color-coded targets."
DROPOFF_RULE = ("The dropoff is only for boxes whose order has been changed to the dropoff. "
                "Putting any other box into the dropoff counts as a wrong delivery, and a wrong delivery cannot be undone.")
TASK = ("Each robot occupies a 1x1 square identified by its center coordinates. It can move one box "
        "in its square to a neighboring square or to a matching target in its square. "
        "Each square can contain multiple boxes and targets.")
ACTION_EXAMPLES = "Example actions are move(box_blue, square[0.5, 1.5]) and move(box_blue, target_blue)."
BREVITY = "Respond concisely."
JOINT_WRITER = "Write a joint entry for every step, choosing the actions of all robots."
OWN_WRITER = "Write an individual entry for every step, choosing only the action of {speaker}."
FORMAT = ("Use a joint object mapping each acting Agent[row, col] to its action string, with {} for an idle step. "
          "Use one action string or the JSON literal null for an individual entry. "
          "Assume the earlier entries have been executed. Return only the list.")
REPAIR_INSTRUCTION = "Revise your list using the same board, writer assignment and output format."
UNREADABLE = "The reply could not be read in the requested JSON format."
INVALID_ACTIONS = "First-step actions outside the current doable lists: "


def build_prompt(rows, cols, state, responses, states, *, horizon, history_method, history_window,
                 state_position, robot=None, earlier=None, step_offset=0, strip_style=False,
                 announcement="", dropoff_rule=False, returned_only=False):
    """robot is a zero-based grid index. The history budget is independent of the reader."""
    if state_position not in ("before", "after") or horizon < 1 or history_window < 0:
        raise ValueError("Invalid matched prompt settings")
    if not states or states[-1] != state or len(states) != len(responses) + 1:
        raise ValueError("Expected one source state for each step, including the current state")
    if history_method in ("none", "_wo_any_dialogue_history"):
        history_window = 0
    elif history_method not in ("authors", "dialogue", "_w_only_state_action_history", "_w_all_dialogue_history"):
        raise ValueError("Unknown history method")
    # Matched history contains public executed state/actions for either nonempty method.
    past = state_action_history(responses, states, history_window, step_offset=step_offset)
    history = HISTORY_HEADING + "\n" + past
    board = announcement + STATE_HEADING + "\n" + state_update_func(rows, cols, state, returned_only)
    goal = GOAL + (" " + DROPOFF_RULE if dropoff_rule in (True, "on") else "")
    intro = [goal, TASK]
    if not strip_style:
        intro.append(ACTION_EXAMPLES)
    intro = "\n".join(intro) + "\n\n"
    if robot is None:
        writer = JOINT_WRITER
    else:
        speaker = agent_at((robot[0] + .5, robot[1] + .5))
        writer = OWN_WRITER.format(speaker=speaker) + "\n" + OWN_DIALOGUE + json.dumps(earlier or {})
    layout = [board, history] if state_position == "before" else [history, board]
    output = [writer, f"Return a JSON list for the next {horizon} steps in execution order.", FORMAT]
    if not strip_style:
        output.append(BREVITY)
    prompt = AfterHistoryPrompt(intro + "\n".join(layout) + "\n" + "\n".join(output))
    prompt.state_offset = len(intro) + (len(history) + 1 if state_position == "after" else 0) + len(announcement)
    return prompt
