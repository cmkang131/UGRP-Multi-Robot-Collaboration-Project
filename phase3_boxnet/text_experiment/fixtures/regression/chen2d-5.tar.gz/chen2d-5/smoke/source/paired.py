"""Map-paired strict-success changes and an exact sign test of CMAS minus DMAS changes."""
import argparse
from collections import defaultdict
from fractions import Fraction
from math import comb

from relay import SPEECH_RULES
from storage import local_path
from summarize import assigned_episodes, episode_csv


def sign_test(positive, negative):
    n = positive + negative
    if not n:
        return None
    tail = sum(comb(n, i) for i in range(min(positive, negative) + 1))
    return min(Fraction(1), Fraction(2 * tail, 2 ** n))


def report_pairs(assigned, rows, a, b):
    if a == b:
        raise ValueError("Choose two distinct speech rules")
    observed = {row["episode_id"]: int(row["finished"] and row["strict_success"]) for row in rows}
    groups = defaultdict(lambda: defaultdict(dict))
    hashes = {}
    for name, item in assigned.items():
        rule = item["speech"]
        if rule not in (a, b):
            continue
        group = item["size"], item["condition"], item["tell"] or "-"
        seed, fw = item["env_seed"], item["framework"]
        inputs = item.get("env_sha256"), item.get("event_sha256"), item.get("speech_event_sha256")
        if hashes.setdefault((group, seed), inputs) != inputs:
            raise ValueError(f"Map inputs differ for {group}, slot {seed}")
        scores = groups[group][fw].setdefault(seed, {})
        if rule in scores:
            raise ValueError(f"Duplicate {rule} assignment for {group}, {fw}, slot {seed}")
        scores[rule] = observed.get(name, 0)
    if not groups:
        raise ValueError("Neither requested speech rule has assigned episodes")
    for group, frameworks in sorted(groups.items()):
        print(f"{' / '.join(group)}   a={a}   b={b}")
        print(f"framework | map | {a} | {b} | b-a")
        deltas = {}
        for fw, maps in sorted(frameworks.items()):
            changes = {}
            for seed, scores in sorted(maps.items()):
                if a in scores and b in scores:
                    changes[seed] = scores[b] - scores[a]
                print(f"{fw} | {seed} | {scores.get(a, 'unassigned')} | {scores.get(b, 'unassigned')} | "
                      f"{changes.get(seed, 'NA')}")
            values = list(changes.values())
            print(f"{fw}   b better={values.count(1)}   a better={values.count(-1)}   tie={values.count(0)}"
                  f"   unpaired={len(maps) - len(changes)}")
            deltas[fw] = changes
        cmas, dmas = deltas.get("CMAS", {}), deltas.get("DMAS", {})
        shared = cmas.keys() & dmas.keys()
        differences = [cmas[s] - dmas[s] for s in shared]
        positive, negative = sum(d > 0 for d in differences), sum(d < 0 for d in differences)
        p = sign_test(positive, negative)
        probability = "NA" if p is None else f"{p} ({float(p):.8g})"
        print(f"CMAS minus DMAS   positive={positive}   negative={negative}   ties dropped={differences.count(0)}"
              f"   n used={positive + negative}   exact two-sided sign p={probability}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("rundir")
    parser.add_argument("--a", required=True, choices=SPEECH_RULES)
    parser.add_argument("--b", required=True, choices=SPEECH_RULES)
    args = parser.parse_args()
    try:
        out = local_path(args.rundir)
        rows = episode_csv(out)
        report_pairs(assigned_episodes(out, rows), rows, args.a, args.b)
    except ValueError as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
