"""Intervention, observation and scoring around the authors' planning loop."""
import copy
import importlib
import json
import re
import time
from collections import Counter, defaultdict
from dataclasses import dataclass
from decimal import Decimal
from pathlib import Path

from LLM import MAX_OUTPUT_TOKENS, CallSession
from limits import CALL_CEILING, Invocation, StopEpisode
from map_events import (DROPOFF_MODES, EVENT_FILE_VERSION, agent_at, boxes, cell_key, coordinates,
                        distance, event_path, speech_fields, step_limit)
from plan_parse import PlanParser
from relay import SPEECH_RULES, Relay
from storage import code_version, digest, read_json, write_json

run_exp = importlib.import_module("env1-box-arrange").run_exp


def change_orders(state, assignment, kind, step, origin=None, *, dropoff="event"):
    after = copy.deepcopy(state)
    site = "dropoff" if dropoff == "always" else "drop-off"
    if kind == "e1":
        colour, dest = assignment["A"], assignment["D"]
        affected = boxes(state)[colour]
        item = f"box_{colour}"
        notice = (f"the order for boxes of colour {colour} has changed. They are no longer wanted in "
                  f"target_{colour}. They are now wanted in the {site} at square{dest}. A box_{colour} "
                  f"that is put into target_{colour} from now on counts as a wrong delivery.")
    else:
        colour, dest = assignment["A2"], assignment["D2"]
        affected = 1
        item = f"box_{colour}"
        if dropoff == "always":
            notice = (f"the box of colour {colour} that was just delivered at square{list(origin)} was not accepted. "
                      f"It is back in square{list(origin)} and is now wanted in the dropoff at square{dest}.")
        else:
            item += "_returned"
            notice = (f"the box of colour {colour} that was just delivered was not accepted. It is back "
                      f"in square{list(origin)} as {item} and is now wanted in the drop-off at square{dest}.")
        after[cell_key(origin)].append(item)
    if dropoff == "event":
        after[cell_key(dest)].append("dropoff_" + colour)
    return dict(kind=kind, step=step, A=colour, D=dest, X=list(origin) if origin is not None else None,
                affected_box=item, box_A_left=affected,
                announcement=f"Change of orders (announced after step {step}): " + notice,
                state_before=state, state_after=after)


class BoxIdentities:
    """Private e2 bookkeeping. The planner sees only the ordinary item strings."""
    def __init__(self, state):
        self.cells = {coordinates(key): defaultdict(list) for key in state}
        next_id = 0
        for square in sorted(self.cells):
            for item in state[cell_key(square)]:
                if item.startswith("box_"):
                    self.cells[square][item].append(next_id)
                    next_id += 1
        self.returned_id = None

    def restore(self, origin, item, box_id):
        self.returned_id = box_id
        self.cells[origin][item].append(box_id)

    def returned_present(self, item):
        return any(self.returned_id in cell.get(item, ()) for cell in self.cells.values())

    def apply(self, origin, item, target):
        ids = self.cells[origin][item]
        # Prefer the oldest ordinary copy, even if it arrived after the returned one.
        index = 1 if len(ids) > 1 and ids[0] == self.returned_id else 0
        box_id = ids.pop(index)
        if isinstance(target, tuple):
            self.cells[target][item].append(box_id)
        return box_id


@dataclass(frozen=True)
class Spec:
    rows: int
    cols: int
    framework: str
    condition: str
    seed: int
    env_path: Path
    env_hash: str
    event_hash: str
    tell: str = "all"
    parse_mode: str = "lenient"
    event_step_override: int | None = None
    dropoff: str = "always"
    speech: str = "authors"

    def __post_init__(self):
        if self.dropoff not in DROPOFF_MODES:
            raise ValueError(f"Unknown dropoff mode: {self.dropoff}")
        if self.speech not in SPEECH_RULES:
            raise ValueError(f"Unknown speech rule: {self.speech}")

    @property
    def size(self):
        return f"{self.rows}x{self.cols}"

    @property
    def name(self):
        condition = self.condition if self.condition == "static" else f"{self.condition}_{self.tell}"
        suffix = "" if self.speech == "authors" else "_" + self.speech
        return f"{self.size}_{self.framework}_{condition}_env{self.seed}{suffix}"


class Episode:
    def __init__(self, spec, session, state, previous, assignment, speech_map):
        self.spec, self.session, self.state = spec, session, state
        self.condition, self.assignment = spec.condition, assignment
        self.speech_map = speech_map
        self.relay = Relay(spec, speech_map["wording"])
        self.scheduled = assignment["event_step"] if spec.event_step_override is None else spec.event_step_override
        self.leader = assignment["L2"] if self.condition == "e2" else assignment["L"]
        self.member = None if self.condition == "e2" else assignment["M"]
        self.parser = PlanParser(spec.parse_mode, session.mark_rescue)
        self.previous = {it["step"]: it for it in previous.get("iterations", [])}
        self.iterations = []
        self.event = None
        self.correct = self.wrong = self.dropoffs = 0
        self.steps_to_last_dropoff = None
        self.robots = [agent_at(p) for p in sorted(map(coordinates, state))]
        self.box_ids = None
        if spec.dropoff == "always":
            self.state = copy.deepcopy(state)
            dest = assignment["D2"] if self.condition == "e2" else assignment["D"]
            self.state[cell_key(dest)].append("dropoff")
            if self.condition == "e2":
                self.box_ids = BoxIdentities(state)
        if self.condition == "e1" and self.scheduled == 0:
            self.fire_event(0)

    @property
    def recipients(self):
        if self.spec.tell == "all":
            return self.robots
        if self.spec.tell == "leader":
            return [self.leader]
        return [self.member] if self.member is not None else []

    def fire_event(self, step, origin=None, box_id=None):
        if self.condition == "e2":
            self.member = agent_at(origin)
        self.event = change_orders(self.state, self.assignment, self.condition, step, origin, dropoff=self.spec.dropoff)
        if self.box_ids is not None:
            self.box_ids.restore(origin, self.event["affected_box"], box_id)
            self.event["returned_box_id"] = box_id
        self.event.update(L=self.leader, M=self.member, leader_is_member=self.leader == self.member)
        self.state = self.event["state_after"]
        self.relay.prepare(self.recipients, self.robots, self.leader, step)

    def relay_after_step(self, step):
        if self.event and self.event["step"] == step:
            self.relay.forward(self)

    def with_messages(self, prompt):
        # Insert after the authors have selected their history and before saving the prompt.
        return self.relay.insert(prompt, self.session.speaker, self.session.role)

    def address(self, robot, role):
        self.session.speaker, self.session.role = robot, role
        self.session.told = (self.event is not None and robot in self.recipients
                             and (self.spec.tell != "member" or role != "central"))
        return self.event["announcement"] + "\n" if self.session.told else ""

    def address_central(self):
        return self.address(self.leader, "central")

    def address_local(self, row, col):
        role = "review" if self.spec.framework == "HMAS-2" else "dialogue"
        return self.address(agent_at((row + 0.5, col + 0.5)), role)

    @property
    def boxes_left(self):
        return boxes(self.state).total()

    def begin_iteration(self, step):
        self.session.step, self.session.round = step, 0
        self.iterations.append(dict(step=step, executed=False, rounds=0, calls=0, planning_seconds=None))
        if self.event:
            self.iterations[-1].update(plan_maker_call=None, plan_maker=None, plan_maker_role=None,
                                       plan_maker_told=None, plan_maker_robot_told=None,
                                       plan_maker_message_block=None, plan_maker_had_news=None)
        self.start = time.monotonic()
        self.calls_before = self.session.api_calls

    def set_round(self, number):
        self.session.round = self.iterations[-1]["rounds"] = number

    def finish_planning(self):
        if not self.iterations:
            return
        current = self.iterations[-1]
        if current["planning_seconds"] is not None:
            return
        prior = self.previous.get(current["step"], {})
        seconds = prior.get("planning_seconds") or 0.0
        if not prior.get("executed"):
            seconds += time.monotonic() - self.start
        current.update(planning_seconds=seconds, calls=self.session.api_calls - self.calls_before)

    def executed(self, state, issued, applied, feedback, plan_call):
        it = self.iterations[-1]
        step = it["step"]
        it.update(executed=True, issued_plan=issued, applied_actions=applied, execution_feedback=feedback)
        affected_box = self.event["affected_box"] if self.event else None
        wrong_before = self.wrong
        towards = None
        if self.event:
            present = (self.box_ids.returned_present(affected_box) if self.box_ids is not None
                       else boxes(self.state)[affected_box[4:]] > 0)
            if present:
                towards = False
        trigger = None
        if self.box_ids is not None:
            it["applied_box_ids"] = []
        for origin, item, target in applied:
            box_id = None
            if self.box_ids is not None:
                if item.startswith("box_"):
                    box_id = self.box_ids.apply(origin, item, target)
                it["applied_box_ids"].append(box_id)
            if not item.startswith("box_"):
                continue
            affected = item == affected_box and (self.box_ids is None or box_id == self.box_ids.returned_id)
            if isinstance(target, tuple):
                if affected and distance(target, self.event["D"]) < distance(origin, self.event["D"]):
                    towards = True
                continue
            # The physical executor accepted a matching target or a drop-off in this square.
            at_dropoff = target == "dropoff" or target.startswith("dropoff_")
            if at_dropoff != affected:
                self.wrong += 1
                continue
            self.correct += 1
            if at_dropoff:
                towards = True
                self.dropoffs += 1
                if self.dropoffs == self.event["box_A_left"]:
                    self.steps_to_last_dropoff = step - self.event["step"]
            elif self.condition == "e2" and self.event is None and trigger is None and item == "box_" + self.assignment["A2"]:
                trigger = origin, box_id

        if self.event:
            if plan_call is not None:
                call = self.session.records[plan_call - 1]
                block = self.relay.in_prompt(call["messages"][1]["content"], call["speaker"], call["role"])
                it.update(plan_maker_call=plan_call, plan_maker=call["speaker"], plan_maker_role=call["role"],
                          plan_maker_told=call["told"], plan_maker_robot_told=call["speaker"] in self.recipients,
                          plan_maker_message_block=block,
                          plan_maker_had_news=call["told"] or block)
            wrong = self.wrong > wrong_before
            if self.spec.dropoff == "event":
                # Version 3 measured a wrong-target instruction in the issued plan.
                colour = self.event["A"]
                wrong = any(re.match(rf"move\({affected_box},\s(target_{colour})\)", v) for v in issued.values())
            it.update(plan_wrong=wrong, plan_towards_dropoff=towards,
                      executed_plan_respected_change=(towards and not wrong) if towards is not None else None)

        self.state = state
        if self.condition == "e1" and step == self.scheduled:
            self.fire_event(step)
        elif trigger is not None:
            self.correct -= 1  # Cancel exactly the first delivery in the authors' execution order.
            self.fire_event(step, *trigger)
        return self.state

    def communication(self, calls):
        turns = dict.fromkeys(self.recipients, 0) if self.condition != "static" else {}
        post = []
        if self.event:
            post = [it for it in self.iterations if it["step"] > self.event["step"]]
            by_step = {it["step"]: [] for it in post}
            for call in calls:
                if call["told"] and call["step"] in by_step:
                    by_step[call["step"]].append(call)
                    turns[call["speaker"]] += 1
            site = "dropoff" if self.spec.dropoff == "always" else "dropoff_" + self.event["A"]
            markers = (site, "drop-off", "change of orders")
            for it in post:
                records = by_step[it["step"]]
                speakers = sorted({c["speaker"] for c in records
                                   if any(m in (c["response"] or "").lower() for m in markers)})
                it.update(told_turns=dict(Counter(c["speaker"] for c in records)),
                          mentioning_agents=speakers, told_agent_mentioned_change=bool(speakers))
                it.setdefault("executed_plan_respected_change", None)
        return turns, post

    def speaking_order(self, calls, post):
        recipients = self.recipients if self.condition != "static" else []
        framework = self.spec.framework
        fixed = {}
        if framework in ("DMAS", "HMAS-1"):
            fixed = {robot: i for i, robot in enumerate(self.robots, 1) if robot in recipients}
        elif framework == "CMAS":
            fixed = {robot: 1 if robot == self.leader and self.spec.tell != "member" else None
                     for robot in recipients}
        elif framework == "HMAS-2":
            for it in self.iterations:
                proposal = it.get("central_plan_agents")
                it["told_in_central_plan"] = {robot: robot in proposal if proposal is not None else None
                                              for robot in recipients}

        positions = dict.fromkeys(recipients)
        speakers = None
        if post:
            speakers = []
            slots = {}
            for call in calls:
                if call["step"] != post["step"] or call["status"] != "ok" or not call["response"]:
                    continue
                robot = call["speaker"]
                speakers.append(robot)
                # Count a central turn and a local turn as different speaking slots.
                index = slots.setdefault((call["role"], robot), len(slots) + 1)
                if call["told"] and positions[robot] is None:
                    positions[robot] = index
        return dict(told_order_positions=fixed, first_post_event_speakers=speakers,
                    first_told_speaker_positions=positions,
                    first_told_agent_spoke=any(p is not None for p in positions.values()) if post else None)

    def result(self, model, script, label, detail, interrupted):
        self.finish_planning()
        event = self.event or {}
        calls = [r for r in self.session.records[:self.session.cursor] if r["api_calls"]]
        author_calls = [r for r in calls if r["role"] != "relay"]
        relay_calls = [r for r in calls if r["role"] == "relay"]
        turns, after = self.communication(author_calls)
        post = after[0] if after else {}
        speaking = self.speaking_order(author_calls, post)
        later = [it for it in after[1:] if it["told_agent_mentioned_change"]]
        def total(field, records=calls):
            values = [r[field] for r in records]
            if any(v is None for v in values):
                return None
            if field.endswith("cost_usd"):
                return float(sum(Decimal(str(v)) for v in values))
            return sum(values)
        prompt, completion = total("prompt_tokens"), total("completion_tokens")
        relay_totals = {"relay_" + field: total(field, relay_calls) for field in
                        ("prompt_tokens", "completion_tokens", "reasoning_tokens", "cost_usd",
                         "known_prompt_tokens", "known_completion_tokens", "known_reasoning_tokens",
                         "known_reported_cost_usd", "guard_cost_usd")}
        relay_prompt, relay_completion = relay_totals["relay_prompt_tokens"], relay_totals["relay_completion_tokens"]
        relay_totals["relay_tokens"] = relay_prompt + relay_completion if None not in (relay_prompt, relay_completion) else None
        assignment = self.assignment
        return dict(episode_id=self.spec.name, code_version=code_version(), size=self.spec.size,
                    framework=self.spec.framework, condition=self.condition, dropoff=self.spec.dropoff,
                    tell=self.spec.tell if self.condition != "static" else None, parse=self.spec.parse_mode,
                    env_seed=self.spec.seed, env_sha256=self.spec.env_hash, event_sha256=self.spec.event_hash,
                    event_file_version=assignment["event_file_version"], max_output_tokens=self.session.max_output_tokens,
                    map_assignment=assignment, L=self.leader, M=self.member, S=assignment["S"],
                    leader_is_member=(self.leader == self.member if self.member is not None else None),
                    model=model, fake_script=script if model == "fake" else None,
                    usage_source="scripted" if model == "fake" else "api", finished=not interrupted,
                    success_failure=label, detail=detail, success=label == "success",
                    steps=sum(it["executed"] for it in self.iterations),
                    authors_env_action_times=len(self.iterations), api_calls=self.session.api_calls,
                    retried_calls=sum(r["attempt_count"] > 1 for r in calls),
                    truncated_attempts=sum(r["attempt_kinds"].count("truncated") for r in calls),
                    prompt_tokens=prompt, completion_tokens=completion, reasoning_tokens=total("reasoning_tokens"),
                    known_prompt_tokens=total("known_prompt_tokens"), known_completion_tokens=total("known_completion_tokens"),
                    known_reasoning_tokens=total("known_reasoning_tokens"),
                    tokens=prompt + completion if prompt is not None and completion is not None else None,
                    cost_usd=total("cost_usd"),
                    known_reported_cost_usd=total("known_reported_cost_usd"),
                    guard_cost_usd=total("guard_cost_usd"), correct_deliveries=self.correct,
                    wrong_deliveries=self.wrong, boxes_left=self.boxes_left,
                    strict_success=not interrupted and self.boxes_left == 0 and self.wrong == 0,
                    event_step=event.get("step"), scheduled_event_step=self.scheduled if self.condition == "e1" else None,
                    event_fired=bool(event), event_nothing_to_change=bool(event) and event["box_A_left"] == 0,
                    event_not_fired=self.condition != "static" and not event,
                    A=assignment["A"], D=assignment["D"], A2=assignment["A2"], D2=assignment["D2"],
                    box_A_left_at_event=event.get("box_A_left"),
                    first_plan_after_event_wrong=post.get("plan_wrong"),
                    first_plan_after_event_towards_dropoff=post.get("plan_towards_dropoff"),
                    steps_to_last_dropoff=self.steps_to_last_dropoff,
                    trigger_step=event.get("step") if self.condition == "e2" else None,
                    steps_to_returned_dropoff=self.steps_to_last_dropoff if self.condition == "e2" else None,
                    first_plan_returned_towards_D2=post.get("plan_towards_dropoff") if self.condition == "e2" else None,
                    post_event_calls=post.get("calls"), post_event_planning_seconds=post.get("planning_seconds"),
                    post_event_rounds=post.get("rounds"), told_turns_after_event=turns, **speaking,
                    first_told_agent_mentioned_change=post.get("told_agent_mentioned_change"),
                    first_plan_respected_change=post.get("executed_plan_respected_change"),
                    later_mention_iterations=len(later),
                    later_mention_iterations_respected=sum(it["executed_plan_respected_change"] is True for it in later),
                    lenient_rescues=sum(r["lenient_rescue"] for r in calls),
                    episode_call_ceiling=self.session.ceiling, call_ceiling=label == CALL_CEILING,
                    event=self.event, final_state=self.state, iterations=self.iterations,
                    speech=self.spec.speech, **self.speech_map, relay_records=self.relay.records,
                    relay_calls=sum(c["api_calls"] for c in relay_calls),
                    relay_seconds=sum(c["elapsed_seconds"] for c in relay_calls), **relay_totals,
                    first_plan_maker_told=post.get("plan_maker_told"),
                    first_plan_maker_message_block=post.get("plan_maker_message_block"),
                    first_plan_maker_had_news=post.get("plan_maker_had_news"),
                    temperature=self.session.temperature, retry_temperature=self.session.retry_temperature)


def admit_episode(spec, out, budget_path, max_output_tokens, temperature, retry_temperature):
    directory = out / "episodes" / spec.name
    result_path = directory / "episode.json"
    previous = read_json(result_path) if result_path.exists() else {}
    if previous and (previous["env_sha256"], previous.get("event_sha256"), previous.get("code_version")) != (
            spec.env_hash, spec.event_hash, code_version()):
        raise ValueError(f"Saved episode inputs or code changed: {spec.name}")
    if previous and previous.get("max_output_tokens") != max_output_tokens:
        raise ValueError(f"Saved episode output-token limit changed: {spec.name}")
    if previous and previous.get("dropoff") != spec.dropoff:
        raise ValueError(f"Saved episode dropoff mode changed: {spec.name}")
    if previous and (previous["speech"], previous["temperature"], previous["retry_temperature"]) != (
            spec.speech, temperature, retry_temperature):
        raise ValueError(f"Saved episode speech or temperature changed: {spec.name}")
    if previous.get("finished"):
        return "skipped", previous
    budget = Invocation(out, budget_path)
    try:
        with budget.transaction() as state:
            budget.check(state)
    except StopEpisode:
        return "not started", previous
    return "started", previous


def run_episode(spec, out, budget_path, model, script, ceiling, max_output_tokens=MAX_OUTPUT_TOKENS,
                temperature=0.0, retry_temperature=None, previous=None):
    retry_temperature = temperature if retry_temperature is None else retry_temperature
    if previous is None:
        status, previous = admit_episode(spec, out, budget_path, max_output_tokens, temperature, retry_temperature)
        if status != "started":
            return status
    directory = out / "episodes" / spec.name
    result_path = directory / "episode.json"
    budget = Invocation(out, budget_path)
    data = spec.env_path.read_bytes()
    metadata = event_path(spec.env_path).read_bytes()
    assignment = json.loads(metadata)
    if (digest(data), digest(metadata), assignment["env_sha256"]) != (spec.env_hash, spec.event_hash, spec.env_hash):
        raise ValueError(f"Environment or event digest mismatch: {spec.name}")
    if assignment.get("event_file_version") != EVENT_FILE_VERSION:
        raise ValueError(f"Unexpected event file version: {spec.env_path}")
    state = json.loads(data)
    speech_map = speech_fields(assignment, spec.rows, spec.cols, spec.seed)
    extra = spec.env_path.with_suffix(".speech.event.json")
    if extra.exists():
        frozen = read_json(extra)
        if frozen.get("source_event_sha256") != spec.event_hash or any(frozen[k] != v for k, v in speech_map.items()):
            raise ValueError(f"Wrong speech event for {spec.name}")
        speech_map = {k: frozen[k] for k in speech_map}
    directory.mkdir(parents=True, exist_ok=True)
    with CallSession(directory, budget, model, script, ceiling, max_output_tokens, temperature, retry_temperature) as session:
        episode = Episode(spec, session, state, previous, assignment, speech_map)
        detail, interrupted = "", False
        try:
            label = run_exp(str(directory), episode.state, spec.rows, spec.cols, step_limit(spec.rows, spec.cols),
                            episode, spec.framework, model)
        except StopEpisode as stop:
            label, detail, interrupted = stop.label, stop.detail, stop.interrupted
        except re.error:
            label, detail = "Hallucination of wrong plan", "Upstream syntactic checker raised on invalid JSON/shape"
        result = episode.result(model, script, label, detail, interrupted)
        write_json(result_path, result)
        for filename, value in (("success_failure.txt", label),
                                ("env_action_times.txt", str(result["authors_env_action_times"])),
                                ("token_num_count.txt", "".join(
                                    f'{r["prompt_tokens"] + r["completion_tokens"]}\n'
                                    if r["prompt_tokens"] is not None and r["completion_tokens"] is not None
                                    else 'NA\n' for r in session.records[:session.cursor] if r["api_calls"]))):
            (directory / filename).write_text(value, encoding="utf-8")
        return label
