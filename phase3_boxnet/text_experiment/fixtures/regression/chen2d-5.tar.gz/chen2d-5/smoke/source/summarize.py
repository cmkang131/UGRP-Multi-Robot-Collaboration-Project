"""Rebuild episode CSVs and compare recorded episodes from compatible runs."""
import argparse
import csv
import json
from collections import Counter, defaultdict
from statistics import mean

from limits import CALL_CEILING, CALL_LIMIT, CLIENT_LIMIT, COST_LIMIT, MODEL_SERVICE, OUTPUT_LIMIT, TOKEN_LIMIT
from map_events import DROPOFF_MODES
from relay import SPEECH_RULES
from storage import atomic_file, local_path, locked, read_json, version_from_hashes

COLUMNS = (
    "episode_id code_version event_file_version max_output_tokens dropoff size framework condition tell parse env_seed env_sha256 event_sha256 "
    "model fake_script usage_source finished success_failure detail success strict_success "
    "steps authors_env_action_times api_calls retried_calls truncated_attempts prompt_tokens completion_tokens reasoning_tokens "
    "known_prompt_tokens known_completion_tokens known_reasoning_tokens "
    "tokens cost_usd known_reported_cost_usd guard_cost_usd wrong_deliveries correct_deliveries "
    "boxes_left L M leader_is_member A D A2 D2 S scheduled_event_step event_step event_fired event_nothing_to_change "
    "event_not_fired box_A_left_at_event first_plan_after_event_wrong first_plan_after_event_towards_dropoff "
    "steps_to_last_dropoff trigger_step steps_to_returned_dropoff first_plan_returned_towards_D2 "
    "post_event_calls post_event_planning_seconds post_event_rounds told_turns_after_event "
    "told_order_positions first_post_event_speakers first_told_speaker_positions first_told_agent_spoke "
    "first_told_agent_mentioned_change first_plan_respected_change later_mention_iterations "
    "later_mention_iterations_respected lenient_rescues episode_call_ceiling call_ceiling "
    "speech wording stratum member_position temperature retry_temperature relay_records relay_calls relay_seconds "
    "relay_tokens relay_prompt_tokens relay_completion_tokens relay_reasoning_tokens relay_cost_usd relay_known_prompt_tokens "
    "relay_known_completion_tokens relay_known_reasoning_tokens relay_known_reported_cost_usd relay_guard_cost_usd "
    "first_plan_maker_told first_plan_maker_message_block first_plan_maker_had_news"
).split()

# This published protocol predates the mode field and only used the coloured site.
V3_CODE_VERSION = "0bd42cf7f6e1"
V4_CODE_VERSION = "f51489cfe776"
TECHNICAL = {CALL_CEILING, CALL_LIMIT, CLIENT_LIMIT, COST_LIMIT, MODEL_SERVICE, OUTPUT_LIMIT, TOKEN_LIMIT}


def temperatures(record):
    legacy = record.get("code_version") in (V3_CODE_VERSION, V4_CODE_VERSION)
    result = {}
    for key in ("temperature", "retry_temperature"):
        value = record.get(key, 0.0 if legacy else None)
        if type(value) not in (float, int) or not 0 <= value <= 2:
            raise ValueError(f"Missing or invalid {key}")
        result[key] = value
    return result


def recorded_dropoff(record):
    if record.get("code_version") == V3_CODE_VERSION and "dropoff" not in record:
        return "event"
    return record.get("dropoff")


def run_settings(out):
    path = out / "run.json"
    if not path.is_file():
        raise ValueError(f"Missing run.json in {out}")
    config = read_json(path)
    hashes = config.get("source_sha256")
    if not isinstance(hashes, dict) or not hashes or config.get("code_version") != version_from_hashes(hashes):
        raise ValueError(f"Missing or invalid code version in {path}. Version-one runs require the version-one summary.")
    for field in ("event_file_version", "max_output_tokens"):
        if type(config.get(field)) is not int or config[field] < 1:
            raise ValueError(f"Missing or invalid {field} in {path}")
    mode = recorded_dropoff(config)
    if mode not in DROPOFF_MODES or (config["code_version"] == V3_CODE_VERSION and mode != "event"):
        raise ValueError(f"Missing or invalid dropoff mode in {path}")
    config["dropoff"] = mode
    config.update(temperatures(config))
    return config


def episode_csv(out):
    settings = run_settings(out)
    with locked(out / ".summary.lock"):
        rows = []
        for path in sorted((out / "episodes").glob("*/episode.json")):
            row = read_json(path)
            if row.get("code_version") != settings["code_version"]:
                raise ValueError(f"Mixed or missing code version in {path}")
            if recorded_dropoff(row) != settings["dropoff"]:
                raise ValueError(f"Mixed or missing dropoff mode in {path}")
            row["dropoff"] = settings["dropoff"]
            for field, value in temperatures(row).items():
                if value != settings[field]:
                    raise ValueError(f"Mixed {field} in {path}")
            if settings["code_version"] not in (V3_CODE_VERSION, V4_CODE_VERSION):
                if row.get("speech") not in SPEECH_RULES or row.get("wording") not in (1, 2):
                    raise ValueError(f"Missing or invalid speech assignment in {path}")
            for field in ("event_file_version", "max_output_tokens"):
                if row.get(field) != settings[field]:
                    raise ValueError(f"Mixed or missing {field} in {path}")
            if row["map_assignment"].get("event_file_version") != settings["event_file_version"]:
                raise ValueError(f"Mixed or missing event_file_version in map assignment in {path}")
            rows.append(row)
        with atomic_file(out / "episodes.csv") as handle:
            writer = csv.DictWriter(handle, fieldnames=COLUMNS, extrasaction="ignore")
            writer.writeheader()
            for row in rows:
                writer.writerow({k: json.dumps(v) if isinstance(v, (list, dict)) else v for k, v in row.items()})
        return rows


def assigned_episodes(out, rows):
    """Repeated invocations can finish an earlier assignment. Count each ID once."""
    names, stopped = set(), {}
    for invocation in sorted((out / "invocations").glob("*.json")):
        names.update(read_json(invocation)["requested"])
        log = invocation.with_suffix(".starts.jsonl")
        if log.is_file():
            for line in log.read_text().splitlines():
                admission = json.loads(line)
                if admission["admission"] == "not started":
                    name = admission["episode_id"]
                    stopped[name] = max(stopped.get(name, ("", "")), (admission["utc"], admission["stop_label"]))
    index = {row["episode_id"]: row for row in rows}
    path = out / "assignments.json"
    current = run_settings(out)["code_version"] not in (V3_CODE_VERSION, V4_CODE_VERSION)
    if current and not path.is_file():
        raise ValueError(f"Missing assignment manifest in {out}")
    manifest = read_json(path) if path.exists() else {}
    if current and (names - manifest.keys() or index.keys() - names):
        raise ValueError(f"Episode IDs disagree with the assigned run in {out}")
    results = {}
    for name in names:
        if name in manifest:
            item = manifest[name].copy()
            if name in index:
                for field in ("size", "framework", "condition", "tell", "speech", "env_seed", "env_sha256",
                              "event_sha256", "stratum", "wording", "member_position"):
                    if item[field] != index[name][field]:
                        raise ValueError(f"Episode disagrees with assigned {field}: {name}")
        else:
            size, framework, condition, *rest = name.split("_")
            row = index.get(name, {})
            d = row.get("D")
            item = dict(size=size, framework=framework, condition=condition, speech="authors",
                        env_seed=int(rest[-1][3:]), tell=None if condition == "static" else rest[0],
                        stratum=("first_column" if d[1] == 0.5 else "other_columns") if d else "unknown")
        if name not in index:
            item["missing_label"] = stopped.get(name, ("", "unrecorded"))[1]
        results[name] = item
    return results


def group_key(row, by=None):
    key = (row["size"], row["framework"], row.get("speech", "authors"), row["condition"], row["tell"] or "-")
    if by == "stratum":
        d = row.get("D")
        return (*key, row.get("stratum", ("first_column" if d[1] == 0.5 else "other_columns") if d else "unknown"))
    return key


def share(values):
    n = len(values)
    if not n:
        return "NA (0/0)"
    positives, missing = sum(v is True for v in values), values.count(None)
    suffix = f" [{missing} NA]" if missing else ""
    return f"{positives/n:.1%} ({positives}/{n}){suffix}"


def compare(rows, planned, by=None, missing=None):
    groups = defaultdict(list)
    for row in rows:
        groups[group_key(row, by)].append(row)
    headers = ("size", "framework", "speech", "condition", "tell", *(("stratum",) if by else ()),
               "assigned", "recorded", "interrupted",
               "event fired", "nothing to change", "not fired", "success", "strict success",
               "mean steps", "mean calls", "retried_calls", "truncated_attempts", "failure output limit",
               "mean tokens", "cost USD", "wrong deliveries",
               "first-plan wrong", "first-plan towards", "first-plan respected", "first told mention",
               "later mention iterations", "later mentions with respected plan", "told turns",
               "mean fixed order position", "mean position among speakers", "first iteration told agent spoke",
               "mean trigger step", "mean steps to last drop-off", "mean steps to returned drop-off",
               "first returned towards D2", "mean first calls", "mean first seconds", "mean first rounds",
               "episodes with rescue", "failure labels (count)", "technical failures by label",
               "share that sent", "first plan-maker had news", "total calls", "relay calls", "relay seconds",
               "relay tokens", "relay cost USD", "relay format errors")
    print(" | ".join(headers))
    for key in sorted(groups.keys() | planned.keys()):
        group = groups[key]
        event = key[3] != "static"
        assigned = planned.get(key, len(group))
        absent = assigned - len(group)
        def get(field):
            return [row[field] for row in group]
        def average(field, digits, *, conditional=False):
            values = [v for v in get(field) if v is not None]
            if not values or (not conditional and len(values) < len(group)):
                return "NA"
            coverage = f" ({len(values)}/{len(group)})" if conditional else ""
            return f"{mean(values):.{digits}f}{coverage}"
        def event_share(field):
            return share(get(field)) if event else "NA"
        def mean_position(field):
            positions = [p for row in group for p in row.get(field, {}).values()]
            known = [p for p in positions if p is not None]
            return f"{mean(known):.2f} ({len(known)}/{len(positions)})" if known else "NA"
        costs = get("cost_usd")
        cost = "NA" if None in costs else f"{sum(costs):.8f}"
        failures = Counter(r["success_failure"] for r in group if not r["success"])
        technical = Counter({k: n for k, n in failures.items() if k in TECHNICAL})
        technical.update((missing or {}).get(key, {}))
        relays = [r for row in group for r in row.get("relay_records", [])]
        relay_tokens = [r.get("relay_tokens", 0) for r in group]
        relay_costs = [r.get("relay_cost_usd", 0) for r in group]
        news = [r.get("first_plan_maker_had_news") for r in group] + [None] * absent
        strict = [bool(r["finished"] and r["strict_success"]) for r in group] + [False] * absent
        line = (*key, assigned, len(group), sum(not r["finished"] for r in group),
                *(sum(get(f)) if event else "NA" for f in ("event_fired", "event_nothing_to_change", "event_not_fired")),
                share(get("success")), share(strict), average("steps", 2), average("api_calls", 2),
                sum(get("retried_calls")), sum(get("truncated_attempts")), failures[OUTPUT_LIMIT],
                average("tokens", 1), cost, sum(get("wrong_deliveries")), event_share("first_plan_after_event_wrong"),
                event_share("first_plan_after_event_towards_dropoff"), event_share("first_plan_respected_change"),
                event_share("first_told_agent_mentioned_change"), sum(get("later_mention_iterations")) if event else "NA",
                sum(get("later_mention_iterations_respected")) if event else "NA",
                sum(sum(c.values()) for c in get("told_turns_after_event")) if event else "NA",
                mean_position("told_order_positions"), mean_position("first_told_speaker_positions"),
                share([row.get("first_told_agent_spoke") for row in group]) if event else "NA",
                average("trigger_step", 2, conditional=True), average("steps_to_last_dropoff", 2, conditional=True),
                average("steps_to_returned_dropoff", 2, conditional=True),
                event_share("first_plan_returned_towards_D2") if key[3] == "e2" else "NA",
                average("post_event_calls", 2, conditional=True), average("post_event_planning_seconds", 3, conditional=True),
                average("post_event_rounds", 2, conditional=True), share([n > 0 for n in get("lenient_rescues")]),
                ", ".join(f"{s} ({n})" for s, n in sorted(failures.items())) or "—",
                ", ".join(f"{s} ({n})" for s, n in sorted(technical.items())) or "—",
                share([bool(r["recipients"]) for r in relays]) if event else "NA",
                share(news) if event else "NA", sum(get("api_calls")),
                sum(r.get("relay_calls", 0) for r in group), f"{sum(r.get('relay_seconds', 0) for r in group):.3f}",
                sum(relay_tokens) if None not in relay_tokens else "NA",
                f"{sum(relay_costs):.8f}" if None not in relay_costs else "NA",
                sum(r["reply_class"] == "relay_format_error" for r in relays))
        print(" | ".join(map(str, line)))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("runs", nargs="+")
    parser.add_argument("--by", choices=("stratum",))
    args = parser.parse_args()
    try:
        outs = [local_path(p) for p in args.runs]
        if len(set(outs)) != len(outs):
            raise ValueError("A run directory was supplied twice")
        configs = [run_settings(out) for out in outs]
        for field in ("dropoff", "event_file_version", "max_output_tokens", "temperature", "retry_temperature"):
            if len({c[field] for c in configs}) > 1:
                raise ValueError(f"Refusing to mix runs with different {field}")
        if len({c["code_version"] for c in configs}) > 1:
            raise ValueError("Refusing to mix code versions")
        if any(c != configs[0] for c in configs):
            raise ValueError("Run settings differ across the supplied directories")
        rows, planned, missing = [], Counter(), defaultdict(Counter)
        for out in outs:
            recorded = episode_csv(out)
            rows.extend(recorded)
            for assignment in assigned_episodes(out, recorded).values():
                key = group_key(assignment, args.by)
                planned[key] += 1
                if "missing_label" in assignment:
                    missing[key][assignment["missing_label"]] += 1
        print(f'{configs[0]["model"]} · code {configs[0]["code_version"]} · events v{configs[0]["event_file_version"]}'
              f' · dropoff {configs[0]["dropoff"]} · max output tokens {configs[0]["max_output_tokens"]}'
              f' · temperature {configs[0]["temperature"]} · retry {configs[0]["retry_temperature"]} · {len(rows)} episode rows')
        compare(rows, planned, args.by, missing)
    except ValueError as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
