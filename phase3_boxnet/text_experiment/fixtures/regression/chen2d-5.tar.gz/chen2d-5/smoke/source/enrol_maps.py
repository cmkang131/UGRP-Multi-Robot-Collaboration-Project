"""Enrol missing Chen maps and verify the requested maps against the D0 reference."""
import argparse
import re

from env1_create import SIZES, action_from_response, main_maps, saved_env
from map_events import MAIN_SIZES, MAIN_SLOTS, event_path, map_assignment, speech_fields
from storage import ROOT, digest, read_json, write_json

SIZE_NAMES = tuple(f"{r}x{c}" for r, c in SIZES)


def selection(value, allowed=None):
    items = [s.strip() for s in value.split(",")]
    if not all(items) or len(set(items)) != len(items) or (allowed and set(items) - set(allowed)):
        raise ValueError(f"Invalid selection {value!r}. Choices: {allowed}")
    return items


def seed_selection(value):
    seeds = []
    for part in selection(value):
        match = re.fullmatch(r"([0-9]+)(?:-([0-9]+))?", part)
        if not match:
            raise ValueError(f"Expected a nonnegative seed or inclusive range: {part!r}")
        first = int(match[1])
        last = int(match[2]) if match[2] is not None else first
        if last < first:
            raise ValueError(f"Descending seed range: {part!r}")
        seeds.extend(range(first, last + 1))
    if len(seeds) != len(set(seeds)):
        raise ValueError("Environment indices must be distinct")
    return seeds


def speech_event(path, rows, cols, slot):
    original = event_path(path)
    event = read_json(original)
    if "wording" in event:
        return original
    companion = path.with_suffix(".speech.event.json")
    data = dict(event, source_event_sha256=digest(original.read_bytes()), map_set="legacy",
                slot_seed=slot, skipped_seeds=[], **speech_fields(event, rows, cols, slot))
    if not companion.exists():
        write_json(companion, data)
    elif read_json(companion) != data:
        raise ValueError(f"Changed legacy speech event: {companion}")
    return companion


def enrol(sizes, seeds, directory=ROOT / "envs", map_set=None):
    if map_set == "main":
        if any(tuple(map(int, s.split("x"))) not in MAIN_SIZES for s in sizes) or set(seeds) - set(MAIN_SLOTS):
            raise ValueError("Main slots are 100–123 on 2x4 and 4x4")
        print("size | slot | seed | skipped | stratum | M position | wording | A | D | step | boxes left | L")
    else:
        print("size | maps | reference boxes of A left >= 1 | D = [0.5, 0.5]")
    for size in sizes:
        rows, cols = map(int, size.split("x"))
        remaining = first_speaker = 0
        for seed in seeds:
            path, sha = saved_env(rows, cols, seed, directory)
            assignment = read_json(event_path(path))
            main = assignment.get("map_set") == "main"
            reference = (main_maps(rows, cols)[seed][1] if main else
                         map_assignment(read_json(path), seed, sha, rows, cols, action_from_response))
            if assignment != reference or reference["reference_box_A_left"] < 1:
                raise ValueError(f"D0 reference verification failed for {path}")
            if map_set is not None:
                if main != (map_set == "main"):
                    raise ValueError(f"Map already belongs to another set: {path}")
                speech_event(path, rows, cols, seed)
            if map_set == "main":
                print(" | ".join(map(str, (size, seed, reference["seed"], reference["skipped_seeds"],
                    reference["stratum"], reference["member_position"], reference["wording"], reference["A"],
                    reference["D"], reference["event_step"], reference["reference_box_A_left"], reference["L"]))))
            remaining += reference["reference_box_A_left"] >= 1
            first_speaker += reference["D"] == [0.5, 0.5]
        if map_set != "main":
            print(f"{size} | {len(seeds)} | {remaining} | {first_speaker}")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--set", choices=("main", "legacy"), dest="map_set")
    parser.add_argument("--sizes")
    parser.add_argument("--envs", required=True, help="seeds and inclusive ranges, e.g. 0-19")
    args = parser.parse_args()
    try:
        sizes = args.sizes or ("2x4,4x4" if args.map_set == "main" else ",".join(SIZE_NAMES))
        enrol(selection(sizes, SIZE_NAMES), seed_selection(args.envs), map_set=args.map_set)
    except ValueError as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
