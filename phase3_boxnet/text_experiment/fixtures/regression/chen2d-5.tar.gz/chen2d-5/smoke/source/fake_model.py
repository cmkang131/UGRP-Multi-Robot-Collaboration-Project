"""Deterministic offline scripts. The solver sees only the authors' messages."""
import ast
import json
import re
from decimal import Decimal

SCRIPTS = ("correct", "wrong", "non-json", "endless", "invalid", "repair", "feedback", "relay-pass", "relay-invalid")
COST = Decimal("0.001")
OBSERVATION = re.compile(
    r'Agent\[(\d+\.5), (\d+\.5)\]: (?:I am in|in) square\[[^\]]+\], '
    r'(?:I can|can) observe (\[[^\]\n]*\])'
)


def distance(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def plan_from_text(prompt, obey):
    state = {(float(x), float(y)): ast.literal_eval(items)
             for x, y, items in OBSERVATION.findall(prompt)}
    if not state:
        raise ValueError("Fake script could not find the current observations")
    e1 = re.search(r'(?:Change of orders \(announced after step \d+\): the order for boxes|Reroute boxes)'
                   r' of colour (\w+) ', prompt)
    e2 = re.search(r'Change of orders \(announced after step \d+\): the box of colour (\w+) '
                   r'that was just delivered(?: at square(\[[\d., ]+\]))? was not accepted', prompt)
    if not e2:
        e2 = re.search(r'Reroute the rejected box of colour (\w+) from square(\[[\d., ]+\])', prompt)
    diverted = "box_" + e1[1] if obey and e1 else None
    returned = f"box_{e2[1]}_returned" if obey and e2 else None
    neutral = any("dropoff" in items for items in state.values())
    return_square = None
    if returned and neutral and e2[2]:
        return_square = tuple(ast.literal_eval(e2[2]))
        returned = "box_" + e2[1]
        copies = sum(items.count(returned) for items in state.values())
    plan = {}
    for square, items in sorted(state.items()):
        choices = []
        for box in items:
            if not box.startswith("box_"):
                continue
            colour = box[4:]
            site = "target_" + colour
            if box == returned and return_square is not None and copies > 1:
                # Leave the rejected copy at X while ordinary copies go to their targets.
                if square == return_square and items.count(box) == 1:
                    continue
            elif box in (diverted, returned):
                site = "dropoff" if neutral else "dropoff_" + colour.removesuffix("_returned")
            for dest, contents in state.items():
                if site in contents:
                    choices.append((distance(square, dest), box, dest, site))
        if not choices:
            continue
        remaining, box, dest, site = min(choices)
        if remaining:
            neighbour = min(p for p in state if distance(p, square) == 1
                            and distance(p, dest) < remaining)
            site = f"square{list(neighbour)}"
        plan[f"Agent{list(square)}"] = f"move({box}, {site})"
    return json.dumps(plan)


def reply(messages, script):
    prompt = messages[1]["content"]
    last = prompt.splitlines()[-1].strip()
    if last.startswith(("You may forward this notice", "You may keep this notice", "You may send one short message")):
        if script == "relay-pass":
            return "PASS"
        if script == "relay-invalid":
            return "SEND or PASS"
        if last.startswith("You may send one short message"):
            notice = prompt.splitlines()[-2]
            colour = re.search(r'of colour (\w+)', notice)[1]
            squares = re.findall(r'square(\[[\d., ]+\])', notice)
            subject = (f"the rejected box of colour {colour} from square{squares[0]}"
                       if "not accepted" in notice else f"boxes of colour {colour}")
            return f"Reroute {subject} to the dropoff at square{squares[-1]}."
        return "SEND"
    if script == "non-json":
        return "This answer contains no plan."
    if "Please evaluate the given plan." in prompt:
        return "I Agree." if script == "feedback" else "I Agree"
    dialogue = "[Action Output Instruction]" in prompt and len(messages) == 2
    if script == "endless" and dialogue:
        return "PROCEED"
    if script == "invalid" or (script == "repair" and len(messages) == 2):
        plan = '{"Agent[0.5, 0.5]":"move(box_missing, target_missing)"}'
    else:
        plan = plan_from_text(prompt, obey=script != "wrong")
    return "EXECUTE\n" + plan if dialogue else plan
