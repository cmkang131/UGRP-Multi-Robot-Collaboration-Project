"""Seeded map-level assignments and the deterministic static reference planner."""
import random
from collections import Counter

EVENT_FILE_VERSION = 3
DROPOFF_MODES = ("always", "event")
MAIN_SLOTS = tuple(range(100, 124))
MAIN_SIZES = ((2, 4), (4, 4))


class NoAdmissibleDestination(ValueError):
    """The assigned stratum has no D satisfying both D0 restrictions."""


def main_design(rows, cols):
    slots = list(MAIN_SLOTS)
    random.Random(f"chen2d-5/{rows}x{cols}/strata").shuffle(slots)
    design = {}
    for group, stratum in ((slots[:12], "first_column"), (slots[12:], "other_columns")):
        wording = [1, 2] * 6
        random.Random(f"chen2d-5/{rows}x{cols}/{stratum}/wording").shuffle(wording)
        design.update({slot: (stratum, w) for slot, w in zip(group, wording)})
    return design


def speech_fields(assignment, rows, cols, slot):
    row, col = map(int, assignment["D"])
    if "wording" in assignment:
        return {k: assignment[k] for k in ("stratum", "member_position", "wording")}
    # Frozen D0 maps use balanced, seeded blocks of four, including Side C (0–3).
    wording = [1, 1, 2, 2]
    random.Random(f"chen2d-5/legacy/{rows}x{cols}/{slot // 4}").shuffle(wording)
    return dict(stratum="first_column" if col == 0 else "other_columns",
                member_position=row * cols + col + 1, wording=wording[slot % 4])


def coordinates(key):
    return tuple(map(float, key.split("_")))


def cell_key(square):
    return "_".join(map(str, square))


def agent_at(square):
    return f"Agent{list(square)}"


def distance(a, b):
    return abs(a[0] - b[0]) + abs(a[1] - b[1])


def boxes(state):
    return Counter(item[4:] for items in state.values() for item in items if item.startswith("box_"))


def step_limit(rows, cols):
    return 40 if (rows, cols) == (4, 8) else 30


def reference_plan(state):
    """One action per initially occupied square, all selected from the same state."""
    cells = {coordinates(key): items for key, items in state.items()}
    targets = {}
    for square, items in cells.items():
        for item in items:
            if item.startswith("target_"):
                targets.setdefault(item[7:], []).append(square)
    plan = {}
    for square, items in sorted(cells.items()):
        choices = ((distance(square, dest), box, dest)
                   for box in items if box.startswith("box_") for dest in targets[box[4:]])
        best = min(choices, default=None)
        if best is None:
            continue
        remaining, box, dest = best
        location = "target_" + box[4:]
        if remaining:
            hop = min(p for p in cells if distance(square, p) == 1 and distance(p, dest) < remaining)
            location = f"square{list(hop)}"
        plan[agent_at(square)] = f"move({box}, {location})"
    return plan


def reference_trajectory(state, execute):
    """Yield the state and applied physical actions after each static reference step."""
    steps = 0
    while boxes(state):
        plan = reference_plan(state)
        applied = []
        feedback, state = execute(state, plan, applied)
        if not plan or feedback or len(applied) != len(plan):
            raise ValueError(f"Invalid reference joint action at step {steps + 1}: {plan} {feedback}")
        steps += 1
        yield state, applied


def map_assignment(state, seed, env_hash, rows, cols, execute, *, stratum=None):
    rng = random.Random(seed)
    cells = sorted(map(coordinates, state))
    colours = sorted(boxes(state))
    if not colours:
        raise ValueError("Event enrolment requires at least one initial box")
    states = [state]
    first_delivery = {}
    for step, (after, actions) in enumerate(reference_trajectory(state, execute), 1):
        states.append(after)
        for _, box, dest in actions:
            if dest == "target_" + box[4:]:
                first_delivery.setdefault(box[4:], step)

    steps = len(states) - 1
    clamped = max(2, min((steps + 1) // 2, step_limit(rows, cols) // 2))
    # The final reference step removes the last box. Step zero is the initial state.
    event_step = min(clamped, steps - 1)
    at_event = states[event_step]
    remaining = boxes(at_event)
    most = max(remaining.values())
    a = rng.choice([c for c in colours if remaining[c] == most])
    no_target = [p for p in cells if "target_" + a not in state[cell_key(p)]]
    destinations = [p for p in no_target if "box_" + a not in at_event[cell_key(p)]]
    if stratum is not None:
        destinations = [p for p in destinations if (p[1] == 0.5) == (stratum == "first_column")]
        if not destinations:
            raise NoAdmissibleDestination(f"No admissible D for seed {seed} in {stratum}")
    d = rng.choice(destinations or no_target or cells)
    a2 = rng.choice([c for c in colours if first_delivery[c] >= 2] or colours)
    targets = [p for p in cells if "target_" + a2 in state[cell_key(p)]]
    separation = {p: min(distance(p, t) for t in targets) for p in cells}
    threshold = min(2, max(separation.values()))
    d2 = rng.choice([p for p in cells if separation[p] >= threshold])
    leader = rng.choice([p for p in cells if p != d])
    return dict(event_file_version=EVENT_FILE_VERSION, seed=seed, env_sha256=env_hash,
                A=a, D=list(d), S=steps, clamped_event_step=clamped, event_step=event_step,
                event_step_lowered=event_step < clamped,
                reference_boxes_at_event={c: remaining[c] for c in colours},
                reference_box_A_left=remaining[a], reference_first_delivery_steps=first_delivery,
                L=agent_at(leader), M=agent_at(d), A2=a2, D2=list(d2),
                L2=agent_at(rng.choice(cells)), M2=None)


def event_path(env_path):
    return env_path.with_suffix(".event.json")
