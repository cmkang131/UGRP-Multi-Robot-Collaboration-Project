"""Plan selection at the authors' extraction and syntactic-check sites."""
import json
import re

DECODER = json.JSONDecoder()
BRACED = re.compile(r"{.*}", re.DOTALL)
OPEN_BRACE = re.compile(r"{")


def first_object(reply):
    start = max(0, reply.rfind("EXECUTE"))
    for match in OPEN_BRACE.finditer(reply, start):
        try:
            obj, _ = DECODER.raw_decode(reply, match.start())
        except (ValueError, RecursionError):
            continue
        if isinstance(obj, dict):
            # Keep insertion order: the authors' executor applies actions in that order.
            return json.dumps(obj)
    return None


class PlanParser:
    def __init__(self, mode="lenient", mark_rescue=None):
        if mode not in ("lenient", "strict"):
            raise ValueError(f"Unknown parse mode {mode}")
        self.mode = mode
        self.mark_rescue = mark_rescue

    def _select(self, reply, strict_candidate):
        selected = first_object(reply)
        if self.mark_rescue is not None and strict_candidate is not None:
            try:
                original = json.loads(strict_candidate)
                different = not isinstance(original, dict) or json.dumps(original) != selected
            except (ValueError, RecursionError):
                different = True
            if different:
                self.mark_rescue()
        return selected

    def extract(self, reply, *, revision=False, selecting=True):
        match = BRACED.search(reply)
        candidate = match.group() if match else None
        if self.mode == "strict":
            return candidate
        if not selecting:
            # HMAS-1 also uses the brace search as a dialogue-loop sentinel.
            return candidate
        # The upstream HMAS-2 revision gives the checker the whole reply if it matched.
        return self._select(reply, reply if revision and match else candidate)

    def for_check(self, reply):
        if self.mode == "strict":
            return reply
        return self._select(reply, reply)
