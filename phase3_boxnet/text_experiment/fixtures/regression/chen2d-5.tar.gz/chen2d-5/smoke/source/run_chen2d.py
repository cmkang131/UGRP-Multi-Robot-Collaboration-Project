"""Run Chen BoxNet1 with shared seeded environments and optional changed orders."""
import argparse
import json
import math
import os
import random
import uuid
from concurrent.futures import FIRST_COMPLETED, ProcessPoolExecutor, wait
from dataclasses import replace
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from itertools import product

from LLM import BRAIN, MAX_ATTEMPTS, MAX_OUTPUT_TOKENS, MODEL, load_real_api
from enrol_maps import SIZE_NAMES, seed_selection, selection, speech_event
from env1_create import saved_env
from episode import Spec, admit_episode, run_episode
from fake_model import SCRIPTS
from limits import Invocation
from map_events import DROPOFF_MODES, EVENT_FILE_VERSION, event_path
from relay import SPEECH_RULES
from storage import ROOT, digest, local_path, locked, read_json, snapshot, source_hashes, version_from_hashes, write_json
from summarize import episode_csv

FRAMEWORKS = ("CMAS", "HMAS-2", "DMAS", "HMAS-1")


def select_specs(args):
    sizes = selection(args.sizes, SIZE_NAMES)
    frameworks = selection(args.frameworks, FRAMEWORKS)
    conditions = ["e1" if c == "change" else c for c in selection(args.conditions, ("static", "e1", "e2", "change"))]
    if len(set(conditions)) != len(conditions):
        raise ValueError("Duplicate condition (change is an alias for e1)")
    tells = selection(args.tell, ("all", "leader", "member"))
    rules = selection(args.speech, SPEECH_RULES)
    seeds = seed_selection(args.envs)
    specs = []
    for size in sizes:
        rows, cols = map(int, size.split("x"))
        envs = {}
        for seed in seeds:
            path, sha = saved_env(rows, cols, seed)
            envs[seed] = (path, sha, digest(event_path(path).read_bytes()))
        for framework, condition, seed, speech in product(frameworks, conditions, seeds, rules):
            for tell in (["all"] if condition == "static" else tells):
                specs.append(Spec(rows, cols, framework, condition, seed, *envs[seed], tell,
                                  args.parse, args.event_step, args.dropoff, speech))
    return specs


def freeze_assignments(out, specs):
    path = out / "assignments.json"
    assigned = read_json(path) if path.exists() else {}
    maps, frozen = {}, []
    for spec in specs:
        if spec.env_path not in maps:
            dest = out / "maps" / spec.size / spec.env_path.name
            snapshot(spec.env_path, dest, spec.env_hash)
            snapshot(event_path(spec.env_path), event_path(dest), spec.event_hash)
            companion = spec.env_path.with_suffix(".speech.event.json")
            if companion.exists():
                snapshot(companion, dest.with_suffix(".speech.event.json"), digest(companion.read_bytes()))
            effective = speech_event(dest, spec.rows, spec.cols, spec.seed)
            event = read_json(effective)
            maps[spec.env_path] = dest, dict(stratum=event["stratum"], wording=event["wording"],
                member_position=event["member_position"], generation_seed=event["seed"],
                env_sha256=spec.env_hash, event_sha256=spec.event_hash,
                speech_event_sha256=digest(effective.read_bytes()))
        dest, fields = maps[spec.env_path]
        item = dict(episode_id=spec.name, size=spec.size, framework=spec.framework, condition=spec.condition,
                    tell=None if spec.condition == "static" else spec.tell, speech=spec.speech, env_seed=spec.seed, **fields)
        if spec.name in assigned and assigned[spec.name] != item:
            raise ValueError(f"Assignment changed for {spec.name}")
        assigned[spec.name] = item
        frozen.append(replace(spec, env_path=dest))
    write_json(path, assigned)
    return frozen


def run(args, out):
    specs = select_specs(args)
    sources = source_hashes()
    config = dict(code_version=version_from_hashes(sources), source_sha256=sources,
                  model=args.model, parse=args.parse, dropoff=args.dropoff, event_step_override=args.event_step,
                  fake_script=args.fake_script if args.model == "fake" else None,
                  episode_call_ceiling=args.episode_call_ceiling, history="_w_only_state_action_history",
                  event_file_version=EVENT_FILE_VERSION, max_output_tokens=args.max_output_tokens,
                  max_attempts_per_call=MAX_ATTEMPTS, temperature=args.temperature, retry_temperature=args.retry_temperature)
    if args.model != "fake":
        api = load_real_api()
        config.update(real_client_sha256=digest((BRAIN / "llm.py").read_bytes()),
                      hard_episode_calls=api.HARD_EPISODE_CALLS, hard_campaign_usd=api.HARD_CAMPAIGN_USD,
                      retry_total_s=api.RETRY_TOTAL_S, retry_window=os.environ.get("UGRP_V8_RETRY_WINDOW") == "1")
    config_path = out / "run.json"
    if config_path.exists() and read_json(config_path) != config:
        raise ValueError("Run settings or protocol source changed. Use a new output directory.")
    if not config_path.exists():
        if (out / "episodes").exists() or (out / "campaign-calls.jsonl").exists():
            raise ValueError("Existing results require their original run.json")
        write_json(config_path, config)
    for name, sha in sources.items():
        snapshot(ROOT / name, out / "source" / name, sha)
    specs = freeze_assignments(out, specs)
    if args.shuffle is not None:
        random.Random(args.shuffle).shuffle(specs)
    invocations = out / "invocations"
    invocations.mkdir(exist_ok=True)
    path = invocations / (uuid.uuid4().hex + ".json")
    selectors = {k: getattr(args, k) for k in ("sizes", "frameworks", "conditions", "tell", "speech", "envs")}
    Invocation(out, path).create(args.max_calls, args.max_cost_usd, args.model, (s.name for s in specs),
                                 shuffle=args.shuffle, jobs=args.jobs, selectors=selectors)
    other = (out, path, args.model, args.fake_script, args.episode_call_ceiling, args.max_output_tokens,
             args.temperature, args.retry_temperature)
    pending = {}
    def collect():
        done, _ = wait(pending, return_when=FIRST_COMPLETED)
        for future in done:
            print(f"{pending.pop(future)}  {future.result()}", flush=True)
        episode_csv(out)

    # Admission is serial and durable. Up to jobs admitted episodes may plan concurrently.
    with ProcessPoolExecutor(max_workers=args.jobs) as pool, path.with_suffix(".starts.jsonl").open("x") as starts:
        for index, spec in enumerate(specs, 1):
            if len(pending) >= args.jobs:
                collect()
            status, previous = admit_episode(spec, out, path, args.max_output_tokens, args.temperature, args.retry_temperature)
            label = read_json(path)["stop_label"] if status == "not started" else None
            starts.write(json.dumps(dict(index=index, episode_id=spec.name, admission=status, stop_label=label,
                                         utc=datetime.now(timezone.utc).isoformat())) + "\n")
            starts.flush()
            os.fsync(starts.fileno())
            if status == "started":
                pending[pool.submit(run_episode, spec, *other, previous)] = spec.name
            else:
                print(f"{spec.name}  {status}", flush=True)
        while pending:
            collect()
    rows = episode_csv(out)
    state = read_json(path)
    print(f'{len(rows)} recorded episodes. This invocation made {state["calls"]} calls. '
          f'Known {"scripted" if args.model == "fake" else "API-reported"} cost USD {state["reported_cost_usd"]}.')
    if state["stop_label"]:
        print(f'{state["stop_label"]} ({state["stop_detail"]})')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--sizes", default="2x2")
    parser.add_argument("--frameworks", default="CMAS,HMAS-2,DMAS,HMAS-1")
    parser.add_argument("--conditions", "--condition", "--event", default="static,e1,e2",
                        help="static, e1 (order change), e2 (returned delivery), or a comma-separated list")
    parser.add_argument("--tell", default="all", help="all, leader, member or a comma-separated list (static ignores it)")
    parser.add_argument("--speech", default="authors", help="authors, auto, choice, free or a comma-separated list")
    parser.add_argument("--shuffle", type=int, metavar="SEED", help="randomise episode admission using this seed")
    parser.add_argument("--temperature", type=float, default=0.0)
    parser.add_argument("--retry-temperature", type=float, help="temperature immediately after a truncated attempt")
    parser.add_argument("--dropoff", choices=DROPOFF_MODES, default="always",
                        help="persistent neutral site (always, default) or version-3 coloured site (event)")
    parser.add_argument("--event-step", type=int, help="override the e1 trigger with this executed step")
    parser.add_argument("--parse", choices=("lenient", "strict"), default="lenient")
    parser.add_argument("--envs", default="0,1,2", help="seeds and inclusive ranges, e.g. 0-9 or 0,2,4-6")
    parser.add_argument("--out", required=True)
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--episode-call-ceiling", type=int, default=300)
    parser.add_argument("--max-output-tokens", type=int, default=MAX_OUTPUT_TOKENS,
                        help="completion-token limit per HTTP attempt, including reasoning (default: 8192)")
    parser.add_argument("--max-cost-usd", type=Decimal, default=Decimal("1.5"))
    parser.add_argument("--max-calls", type=int)
    parser.add_argument("--model", choices=(MODEL, "fake"), default=MODEL)
    parser.add_argument("--fake-script", choices=SCRIPTS, default="correct")
    try:
        args = parser.parse_args()
        if args.retry_temperature is None:
            args.retry_temperature = args.temperature
        if not all(math.isfinite(t) and 0 <= t <= 2 for t in (args.temperature, args.retry_temperature)):
            raise ValueError("Temperatures must be finite and in [0, 2]")
        if args.max_output_tokens < 1:
            raise ValueError("--max-output-tokens must be positive")
        if args.event_step is not None and args.event_step < 1:
            raise ValueError("--event-step must be a positive executed step number")
        if args.jobs < 1 or args.episode_call_ceiling < 0 or (args.max_calls is not None and args.max_calls < 0):
            raise ValueError("Jobs must be positive and call ceilings nonnegative")
        if not args.max_cost_usd.is_finite() or args.max_cost_usd < 0:
            raise ValueError("Cost cap must be finite and nonnegative")
        if args.fake_script != "correct" and args.model != "fake":
            raise ValueError("--fake-script requires --model fake")
        out = local_path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        with locked(out / ".runner.lock"):
            run(args, out)
    except (ValueError, InvalidOperation) as exc:
        parser.error(str(exc))


if __name__ == "__main__":
    main()
