"""Shared writing instructions, board partitions and history for matched planning."""
import json
from dataclasses import dataclass
from functools import lru_cache

from env1_create import state_update_func
from map_events import agent_at
from prompt_env1 import AfterHistoryPrompt, OWN_DIALOGUE, state_action_history

REPAIRS_PER_WRITER = 2
DEFAULT_ENV_STEPS = 30
DEFAULT_PLANNING_ROUNDS = 30
STATE_HEADING = "Current board and doable actions:"
HISTORY_HEADING = "Earlier executed state and action pairs:"
GOAL = "Match all boxes to their color-coded targets."
DROPOFF_RULE = ("The dropoff is only for boxes whose order has been changed to the dropoff. "
                "Putting any other box into the dropoff counts as a wrong delivery, and a wrong delivery cannot be undone.")
TASK = ("Each robot occupies a 1x1 square identified by its center coordinates. It can move one box "
        "in its square to a neighboring square or to a matching target in its square. "
        "Each square can contain multiple boxes and targets.")
ACTION_EXAMPLES = "Example actions are move(box_blue, square[0.5, 1.5]) and move(box_blue, target_blue)."
BREVITY = "Respond concisely."
JOINT_WRITER = "Write a joint entry for every step, choosing the actions of all robots."
OWN_WRITER = "Write an individual entry for every step, choosing only the action of {speaker}."
GROUP_WRITER = "Write a joint entry for every step, choosing actions only for {robots}."
GROUP_CALL_FIELDS = ("framework", "group_size", "callers_per_round", "assigned_robots",
                     "robots_assigned", "assigned_robots_with_doable_actions")
# Keep the non-shape instruction common, but make the shape itself unambiguous
# for the writer which is actually answering.
FORMAT = "Assume the earlier entries have been executed. Return only the list."
JOINT_FORMAT = "Each list entry is a joint object mapping acting Agent[row, col] names to action strings. Use {} for an idle step."
OWN_FORMAT = "Each list entry is your own action string or the JSON literal null for a wait."
REPAIR_INSTRUCTION = "Revise your list using the same board and writer assignment."
UNREADABLE = "The reply could not be read in the requested JSON format."
INVALID_ACTIONS = "First-step actions outside the current doable lists: "


def block_shapes(rows, cols):
    """Map each permitted writer size to one aligned, repeatable rectangle (rows, columns)."""
    shapes = {}
    for height in range(1, rows + 1):
        for width in range(1, cols + 1):
            if rows % height or cols % width:
                continue
            size = height * width
            shape = height, width
            if size != rows * cols and size in (4, 8) and shape != (2, size // 2):
                continue
            prior = shapes.get(size)
            if prior is None or (abs(height - width), height) < (abs(prior[0] - prior[1]), prior[0]):
                shapes[size] = shape
    return shapes


@dataclass(frozen=True)
class GroupPartition:
    group_size: int
    shape: tuple
    blocks: tuple

    @property
    def writer_framework(self):
        if len(self.blocks) == 1:
            return "CMAS"
        return "OWN" if self.group_size == 1 else "GROUP"

    def record(self):
        return dict(framework="GROUP", group_size=self.group_size, callers_per_round=len(self.blocks),
                    block_shape=list(self.shape), blocks=[list(block) for block in self.blocks])

    def call_scope(self, members, available):
        return dict(framework="GROUP", group_size=self.group_size, callers_per_round=len(self.blocks),
                    assigned_robots=list(members), robots_assigned=len(members),
                    assigned_robots_with_doable_actions=sum(bool(available[name]) for name in members))


@lru_cache(maxsize=128, typed=True)
def group_partition(rows, cols, size):
    shapes = block_shapes(rows, cols)
    if type(size) is not int or size not in shapes:
        valid = ", ".join(map(str, sorted(shapes)))
        raise ValueError(f"--group-size {size} does not tile {rows}x{cols}. Valid sizes: {valid}")
    height, width = shapes[size]
    blocks = tuple(tuple(agent_at((i + .5, j + .5))
                         for i in range(top, top + height) for j in range(left, left + width))
                   for top in range(0, rows, height) for left in range(0, cols, width))
    return GroupPartition(size, (height, width), blocks)


def build_prompt(rows, cols, state, responses, states, *, horizon, history_method, history_window,
                 state_position, robot=None, block=None, earlier=None, step_offset=0, strip_style=False,
                 announcement="", dropoff_rule=False, returned_only=False):
    """robot is a zero-based grid index. The history budget is independent of the reader."""
    if state_position not in ("before", "after") or horizon < 1 or history_window < 0:
        raise ValueError("Invalid matched prompt settings")
    if not states or states[-1] != state or len(states) != len(responses) + 1:
        raise ValueError("Expected one source state for each step, including the current state")
    if history_method in ("none", "_wo_any_dialogue_history"):
        history_window = 0
    elif history_method not in ("authors", "dialogue", "_w_only_state_action_history", "_w_all_dialogue_history"):
        raise ValueError("Unknown history method")
    # Matched history contains public executed state/actions for either nonempty method.
    past = state_action_history(responses, states, history_window, step_offset=step_offset)
    history = HISTORY_HEADING + "\n" + past
    board = announcement + STATE_HEADING + "\n" + state_update_func(rows, cols, state, returned_only)
    goal = GOAL + (" " + DROPOFF_RULE if dropoff_rule in (True, "on") else "")
    intro = [goal, TASK]
    if not strip_style:
        intro.append(ACTION_EXAMPLES)
    intro = "\n".join(intro) + "\n\n"
    if block is not None:
        writer = GROUP_WRITER.format(robots=json.dumps(block))
    elif robot is None:
        writer = JOINT_WRITER
    else:
        speaker = agent_at((robot[0] + .5, robot[1] + .5))
        writer = OWN_WRITER.format(speaker=speaker)
    # Every matched role sees the same peer-list slot; it is empty for the
    # central writer before any submissions, and fills only as writers answer.
    writer += "\n" + OWN_DIALOGUE + json.dumps(earlier or {})
    layout = [board, history] if state_position == "before" else [history, board]
    shape = OWN_FORMAT if robot is not None else JOINT_FORMAT
    output = [writer, f"Return a JSON list for the next {horizon} steps in execution order.", shape, FORMAT]
    if not strip_style:
        output.append(BREVITY)
    prompt = AfterHistoryPrompt(intro + "\n".join(layout) + "\n" + "\n".join(output))
    prompt.state_offset = len(intro) + (len(history) + 1 if state_position == "after" else 0) + len(announcement)
    return prompt
